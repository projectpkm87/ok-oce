import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:laporan_keuangan1/InputPBP.dart';
import 'package:laporan_keuangan1/InputTransaksiPage.dart';
import 'package:laporan_keuangan1/log_page.dart';
import 'package:laporan_keuangan1/log_service.dart';
import 'package:laporan_keuangan1/pages/laporanIncomeMato.dart';
import 'package:laporan_keuangan1/pages/laporanLB.dart';
import 'package:laporan_keuangan1/pages/laporanStok.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// --- Formatter Rupiah global (bisa dipakai dari mana saja)
final NumberFormat _rupiahFmt =
NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

String rupiah(num v) => _rupiahFmt.format(v);

// ---------- KARTU LAPORAN (utility) ----------
Widget _buildLaporanCard({
  required String title,
  required String subtitle,
  required String nominal,
  required VoidCallback onDetailPressed,
}) {
  return Card(
    elevation: 2,
    color: Colors.white,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 14)),
          const SizedBox(height: 8),
          Text(nominal, style: const TextStyle(color: Colors.orange, fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade100,
                foregroundColor: Colors.green.shade800,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                elevation: 0,
              ),
              onPressed: onDetailPressed,
              child: const Text("Detail"),
            ),
          ),
        ],
      ),
    ),
  );
}

class DashboardCabang extends StatefulWidget {
  final String idCabang;
  final String namaCabang;

  const DashboardCabang({
    super.key,
    required this.idCabang,
    required this.namaCabang,
  });

  @override
  State<DashboardCabang> createState() => _DashboardCabangState();
}

class _DashboardCabangState extends State<DashboardCabang> {
  // ====== SUPABASE & NAMA USAHA (APP SETTINGS) ======
  final _supabase = Supabase.instance.client;

  String? _namaUsaha; // tampil di header
  final TextEditingController _namaUsahaCtrl =
  TextEditingController(text: 'NAMA USAHA'); // default isi popup
  bool _savingNamaUsaha = false;

  // ====== STATE LAINNYA ======
  int _selectedIndex = 0;
  final GlobalKey _chartKeySales = GlobalKey();
  final GlobalKey _chartKeyMato = GlobalKey();
  final GlobalKey _chartKeyHPP = GlobalKey();
  final logService = LogService();

  late final String cabangIdKamu;
  late final String namaCabangKamu;
  String? userEmail;

  DateTime? _startDate;
  DateTime? _endDate;
  String _salesPreset = 'all'; // preset: all|month|100

  final List<Map<String, dynamic>> _navItems = [
    {'label': 'Dashboard', 'icon': Icons.dashboard},
    {'label': 'Laporan', 'icon': Icons.insert_chart},
    {'label': 'Mato Cabang', 'icon': Icons.pie_chart},
    {'label': 'Transaksi', 'icon': Icons.receipt_long},
  ];

  // ===== Rekap Transaksi (mutasi-style ala LB) =====
  final _rtFmtDate = DateFormat('d MMM yyyy', 'id_ID');
  final _rtFmtIso = DateFormat('yyyy-MM-dd');
  final _rtFmtCur = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  DateTime? _rtStartDate;
  DateTime? _rtEndDate;

  List<Map<String, dynamic>> _rtRows = [];
  bool _rtLoading = false;

  final _rtHHeader = ScrollController();
  final _rtHBody = ScrollController();
  final _rtVBody = ScrollController();

  final List<String> _rtHeaders = const [
    'Tanggal',
    'Pemasukan',
    'Pengeluaran',
    'Total',
    'Keterangan',
    'Aksi',
  ];
  final List<double> _rtBaseWidths = const [
    160, // Tanggal
    180, // Pemasukan
    180, // Pengeluaran
    180, // Total
    280, // Keterangan
    140, // Aksi
  ];

  @override
  void initState() {
    super.initState();
    _loadNamaUsaha();
    _fetchOmzetFromSupabase();
    cabangIdKamu = widget.idCabang;
    namaCabangKamu = widget.namaCabang;
    userEmail = Supabase.instance.client.auth.currentUser?.email;

    // Rekap Transaksi default = bulan ini
    final now = DateTime.now();
    _rtStartDate = DateTime(now.year, now.month, 1);
    _rtEndDate = DateTime(now.year, now.month + 1, 0);

    // sinkron scroll header <-> body
    _rtHHeader.addListener(() {
      if (_rtHBody.hasClients && _rtHBody.offset != _rtHHeader.offset) {
        _rtHBody.jumpTo(_rtHHeader.offset);
      }
    });
    _rtHBody.addListener(() {
      if (_rtHHeader.hasClients && _rtHHeader.offset != _rtHBody.offset) {
        _rtHHeader.jumpTo(_rtHBody.offset);
      }
    });

    _fetchMutasiData();
  }

  @override
  void dispose() {
    _rtHHeader.dispose();
    _rtHBody.dispose();
    _rtVBody.dispose();
    super.dispose();
  }

  // ================== NAMA USAHA: LOAD / SAVE / DIALOG ==================
  Future<void> _loadNamaUsaha() async {
    try {
      final row = await _supabase.from('app_settings').select('value').eq('key', 'nama_usaha').maybeSingle();

      setState(() {
        _namaUsaha = row?['value'];
        if (_namaUsaha != null) _namaUsahaCtrl.text = _namaUsaha!;
      });

      if (mounted && (_namaUsaha == null || _namaUsaha!.trim().isEmpty)) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _showNamaUsahaDialog(force: true);
        });
      }
    } catch (e) {
      debugPrint('Gagal load nama usaha: $e');
    }
  }

  void _showNamaUsahaDialog({bool force = false}) {
    showDialog(
      context: context,
      barrierDismissible: !force,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('isi nama usaha anda *', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
              const SizedBox(height: 16),
              TextField(
                controller: _namaUsahaCtrl,
                decoration: InputDecoration(
                  hintText: 'Contoh: INMATO APP',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _savingNamaUsaha ? null : _saveNamaUsaha,
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: Text(_savingNamaUsaha ? 'menyimpan...' : 'simpan'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _saveNamaUsaha() async {
    final v = _namaUsahaCtrl.text.trim();
    if (v.isEmpty) return;

    setState(() => _savingNamaUsaha = true);
    try {
      await _supabase.from('app_settings').upsert({'key': 'nama_usaha', 'value': v}, onConflict: 'key');
      setState(() {
        _namaUsaha = v;
        _savingNamaUsaha = false;
      });
      if (Navigator.of(context).canPop()) Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nama usaha disimpan')));
    } catch (e) {
      setState(() => _savingNamaUsaha = false);
      debugPrint('Gagal simpan nama usaha: $e');
    }
  }

  // ================== DATA DASBOR ==================
  Future<List<Map<String, dynamic>>> _fetchSales100Hari() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) throw Exception("User belum login");

    final profile =
    await supabase.from('profiles').select('id_cabang').eq('id', user.id).maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) throw Exception("ID cabang tidak ditemukan");

    final queryBuilder = supabase.from('sales_100_hari').select().eq('id_cabang', idCabang);

    if (_startDate != null) {
      queryBuilder.filter('tanggal', 'gte', _startDate!.toIso8601String());
    }
    if (_endDate != null) {
      queryBuilder.filter('tanggal', 'lte', _endDate!.toIso8601String());
    }

    final response = await queryBuilder.order('tanggal');
    return List<Map<String, dynamic>>.from(response);
  }

  Future<List<Map<String, dynamic>>> _fetchPegawaiFromSupabase() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) {
      throw Exception("User tidak ditemukan.");
    }

    final userProfile = await supabase.from('profiles').select('id_cabang').eq('id', user.id).maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    if (idCabang == null) throw Exception("ID Cabang tidak ditemukan.");

    final response = await supabase.from('profiles').select().eq('id_cabang', idCabang).order('nama');

    return List<Map<String, dynamic>>.from(response);
  }

  Future<Map<String, dynamic>> _fetchProfile() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) throw Exception('User tidak login');

    final data = await Supabase.instance.client.from('profiles').select().eq('id', user.id).maybeSingle();

    if (data == null) throw Exception('Profil tidak ditemukan');
    return data;
  }

  Future<List<Map<String, dynamic>>> _getDetailTransaksi(String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return [];

    final profile = await supabase.from('profiles').select('id_cabang').eq('id', user.id).maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) return [];

    final response = await supabase
        .from('transaksi_harian')
        .select()
        .eq('id_cabang', idCabang)
        .eq('tanggal', tanggal)
        .order('jenis_transaksi');

    return List<Map<String, dynamic>>.from(response);
  }

  /// Ambil transaksi di tanggal tsb, lalu kelompokkan per kategori.
  /// – Jika `jenis_transaksi` kosong, fallback ke tanda `jumlah` (+/-).
  /// – Menggabungkan `kategori` + `sub_kategori` (kalau ada) untuk label yang lebih detail.
  Future<_Breakdown> _fetchKategoriBreakdown(String tanggalIso) async {
    final rows = await _supabase
        .from('transaksi_harian')
        .select('kategori, sub_kategori, custom_label, jumlah, jenis_transaksi')
        .eq('id_cabang', widget.idCabang)
        .eq('tanggal', tanggalIso);

    final inc = <String, int>{};
    final exp = <String, int>{};

    for (final r in rows) {
      final kategori = (r['kategori'] ?? '').toString().trim();
      final sub      = (r['sub_kategori'] ?? '').toString().trim();
      // label: "kategori — sub" jika sub ada
      final labelRaw = [kategori, sub].where((s) => s.isNotEmpty).join(' — ');
      final label    = labelRaw.isEmpty ? 'Lain-lain' : labelRaw;

      // jumlah aman (numeric bisa datang sebagai num atau string)
      num n = 0;
      final j = r['jumlah'];
      if (j is num) n = j;
      else n = num.tryParse(j?.toString() ?? '0') ?? 0;

      String jenis = (r['jenis_transaksi'] ?? '').toString().toLowerCase();
      if (jenis.isEmpty) {
        jenis = n < 0 ? 'pengeluaran' : 'pemasukan';
      }
      final nilaiAbs = n.abs().round();

      if (jenis == 'pengeluaran') {
        exp[label] = (exp[label] ?? 0) + nilaiAbs;
      } else {
        inc[label] = (inc[label] ?? 0) + nilaiAbs;
      }
    }

    return _Breakdown(inc, exp);
  }

  // ================== REKAP TRANSAKSI (mutasi ala LB) ==================
  num _rtNum(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  Future<void> _fetchMutasiData() async {
    if (_rtStartDate == null || _rtEndDate == null) {
      setState(() => _rtRows = []);
      return;
    }
    setState(() => _rtLoading = true);

    try {
      final data = await Supabase.instance.client
          .from('transaksi_harian')
          .select('tanggal, jumlah, keterangan')
          .eq('id_cabang', widget.idCabang)
          .gte('tanggal', _rtFmtIso.format(_rtStartDate!))
          .lte('tanggal', _rtFmtIso.format(_rtEndDate!))
          .order('tanggal');

      final list = List<Map<String, dynamic>>.from(data);

      final Map<String, Map<String, dynamic>> agg = {};
      for (final row in list) {
        final String t = (row['tanggal'] ?? '').toString().substring(0, 10); // yyyy-MM-dd
        final num j = _rtNum(row['jumlah']);
        final String ket = (row['keterangan'] ?? '').toString().trim();

        agg.putIfAbsent(t, () => {
          'tanggal': t,
          'pemasukan': 0,
          'pengeluaran': 0,
          'total': 0,
          'notes': <String>{},
        });

        if (j >= 0) {
          agg[t]!['pemasukan'] = (agg[t]!['pemasukan'] as num) + j;
        } else {
          agg[t]!['pengeluaran'] = (agg[t]!['pengeluaran'] as num) + (-j); // simpan positif
        }
        agg[t]!['total'] = (agg[t]!['total'] as num) + j;

        if (ket.isNotEmpty) {
          (agg[t]!['notes'] as Set<String>).add(ket);
        }
      }

      final rows = agg.values.toList()
        ..sort((a, b) => a['tanggal'].toString().compareTo(b['tanggal'].toString()));

      // gabungkan notes jadi string
      final rtRows = rows.map((m) {
        final notesSet = (m['notes'] as Set<String>);
        String ket = notesSet.take(3).join(' • ');
        if (ket.length > 120) ket = '${ket.substring(0, 120)}…';
        return {
          'tanggal': m['tanggal'],
          'pemasukan': m['pemasukan'],
          'pengeluaran': m['pengeluaran'],
          'total': m['total'],
          'keterangan': ket.isEmpty ? '—' : ket,
        };
      }).toList();

      setState(() => _rtRows = rtRows);
      if (_rtVBody.hasClients) _rtVBody.jumpTo(0);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal memuat transaksi: $e')));
    } finally {
      if (mounted) setState(() => _rtLoading = false);
    }
  }

  Future<void> _rtOpenRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _rtStartDate ?? DateTime(now.year, now.month, 1),
      end: _rtEndDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(useMaterial3: false),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        _rtStartDate = picked.start;
        _rtEndDate = picked.end;
      });
      _fetchMutasiData();
    }
  }

  Future<void> _rtPickDate({required bool isStart}) async {
    final now = DateTime.now();
    final init = isStart ? (_rtStartDate ?? now) : (_rtEndDate ?? _rtStartDate ?? now);

    final picked = await showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 1, 12, 31),
      builder: (ctx, child) => Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );
    if (picked == null) return;

    setState(() {
      if (isStart) {
        _rtStartDate = picked;
        if (_rtEndDate != null && _rtEndDate!.isBefore(_rtStartDate!)) {
          _rtEndDate = _rtStartDate;
        }
      } else {
        _rtEndDate = picked;
        if (_rtStartDate != null && _rtStartDate!.isAfter(_rtEndDate!)) {
          _rtStartDate = _rtEndDate;
        }
      }
    });

    _fetchMutasiData();
  }

  void _rtClearDates() {
    setState(() {
      _rtStartDate = null;
      _rtEndDate = null;
      _rtRows = [];
    });
  }

  Future<void> _rtApplyPreset(String code) async {
    final now = DateTime.now();
    if (code == 'all') {
      setState(() {
        _rtStartDate = DateTime(2020, 1, 1);
        _rtEndDate = now;
      });
    } else if (code == 'month') {
      setState(() {
        _rtStartDate = DateTime(now.year, now.month, 1);
        _rtEndDate = DateTime(now.year, now.month + 1, 0);
      });
    } else if (code == '100') {
      setState(() {
        _rtStartDate = now.subtract(const Duration(days: 99));
        _rtEndDate = now;
      });
    }
    await _fetchMutasiData();
  }

  Widget _rtFilterBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Bar atas
        Row(
          children: [
            const Text('Tanggal (Rentang)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _rtOpenRangePicker,
              icon: const Icon(Icons.date_range, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFE4E9),
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                  side: const BorderSide(color: Colors.black, width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
              label: const Text('Rentang Tanggal'),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: _rtClearDates,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.black, width: 1),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              child: const Text('Clear'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        // Pill tanggal
        Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: () => _rtPickDate(isStart: true),
                borderRadius: BorderRadius.circular(40),
                child: _DatePill(
                  label: 'Tanggal Awal',
                  value: _rtStartDate == null ? '—' : _rtFmtDate.format(_rtStartDate!),
                ),
              ),
            ),
            const SizedBox(width: 8),
            const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            Expanded(
              child: InkWell(
                onTap: () => _rtPickDate(isStart: false),
                borderRadius: BorderRadius.circular(40),
                child: _DatePill(
                  label: 'Tanggal Akhir',
                  value: _rtEndDate == null ? '—' : _rtFmtDate.format(_rtEndDate!),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        // Preset
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _PresetChip(text: 'Semua Data', onTap: () => _rtApplyPreset('all')),
            _PresetChip(text: 'Bulan Ini', onTap: () => _rtApplyPreset('month')),
            _PresetChip(text: '100 Hari Terakhir', onTap: () => _rtApplyPreset('100')),
          ],
        ),
      ],
    );
  }

  Widget _rtBuildHeader(List<double> widths) {
    const double sideInset = 20;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: sideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: {for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])},
        children: [
          TableRow(
            children: List.generate(_rtHeaders.length, (i) {
              return Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  _rtHeaders[i],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _rtCapsuleRow({required Widget child, double top = 12}) {
    return Container(
      margin: EdgeInsets.only(top: top, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 10, offset: const Offset(0, 4)),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: child,
    );
  }

  Widget _rtCellText(String text, {TextAlign align = TextAlign.center}) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Text(
        text,
        textAlign: align,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    );
  }

  Widget _rtBuildPlaceholder(List<double> widths) {
    return _rtCapsuleRow(
      child: Table(
        columnWidths: {for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])},
        children: [
          TableRow(children: List.generate(widths.length, (i) => _rtCellText('–'))),
        ],
      ),
    );
  }

  Widget _rtDataRow({
    required List<double> widths,
    required Map<String, dynamic> r,
    required bool isFirst,
  }) {
    final tanggalIso = r['tanggal'].toString();
    final pemasukan = r['pemasukan'] as num? ?? 0;
    final pengeluaran = r['pengeluaran'] as num? ?? 0;
    final total = r['total'] as num? ?? 0;
    final ket = r['keterangan']?.toString() ?? '—';

    return _rtCapsuleRow(
      top: isFirst ? 6 : 12,
      child: Table(
        columnWidths: {for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])},
        children: [
          TableRow(
            children: [
              _rtCellText(_rtFmtDate.format(DateTime.parse(tanggalIso))),
              _rtCellText(_rtFmtCur.format(pemasukan)),
              _rtCellText(_rtFmtCur.format(pengeluaran)),
              _rtCellText(_rtFmtCur.format(total)),
              _rtCellText(ket, align: TextAlign.left),
              // Aksi
              Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      tooltip: 'Detail',
                      icon: const Icon(Icons.visibility, size: 20),
                      onPressed: () => _showDetailTransaksi(context, tanggalIso),
                    ),
                    IconButton(
                      tooltip: 'Edit Keterangan',
                      icon: const Icon(Icons.edit, size: 20),
                      onPressed: () async {
                        await _editKeteranganTransaksi(context, tanggalIso);
                        await _fetchMutasiData();
                      },
                    ),
                    IconButton(
                      tooltip: 'Hapus',
                      icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                      onPressed: () async {
                        await _deleteLaporan(context, tanggalIso);
                        await _fetchMutasiData();
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ================== UI ==================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Builder(
                  builder: (context) => IconButton(
                    icon: const Icon(Icons.menu, size: 34, color: Colors.black),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                  ),
                ),
                const SizedBox(width: 16),
                Row(
                  children: [
                    Image.asset('assets/logobg.png', height: 85),
                    const SizedBox(width: 10),
                    Row(
                      children: [
                        Text(
                          ((_namaUsaha ?? 'NAMA USAHA')).toUpperCase(),
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 30,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(width: 8),
                        InkWell(
                          onTap: () => _showNamaUsahaDialog(),
                          borderRadius: BorderRadius.circular(24),
                          child: const Padding(
                            padding: EdgeInsets.all(4.0),
                            child: Icon(Icons.edit, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.refresh, size: 20),
                          tooltip: 'Refresh Profil',
                          onPressed: () async {
                            await _fetchProfile();
                            setState(() {});
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Berhasil refresh halaman')),
                            );
                          },
                        ),
                        const Text(
                          'ADMIN CABANG',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      widget.namaCabang.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      // === GANTI bagian drawer: ===
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero, // penting: biar header nempel atas
          children: [
            _FancyDrawerHeader(
              namaUsaha: (_namaUsaha ?? 'NAMA USAHA').toUpperCase(),
              email: userEmail ?? 'Email tidak tersedia',
              role: 'ADMIN CABANG',
              cabang: widget.namaCabang.toUpperCase(),
              photoUrl: Supabase.instance.client.auth.currentUser?.userMetadata?['avatar_url'],
              onTapEditUsaha: _showNamaUsahaDialog,
              onTapSettings: () {
                // TODO: ke halaman pengaturan
              },
            ),

            const SizedBox(height: 6),

            _DrawerItem(
              icon: Icons.home_rounded,
              label: 'Beranda',
              active: _selectedIndex == 0,
              onTap: () {
                Navigator.pop(context);
                setState(() => _selectedIndex = 0);
              },
            ),
            _DrawerItem(
              icon: Icons.payments_rounded,
              label: 'Input Biaya Bahan Pokok',
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.pushNamed(context, '/input-omzet');
                });
              },
            ),
            _DrawerItem(
              icon: Icons.inventory_2_rounded,
              label: 'Input Persedian Bahan Pokok',
              onTap: () {
                Navigator.pop(context);
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => InputPBP(idCabang: widget.idCabang)),
                );
              },
            ),
            _DrawerItem(
              icon: Icons.receipt_long_rounded,
              label: 'Input Transaksi',
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => InputTransaksiPage(cabangId: widget.idCabang)),
                  );
                });
              },
            ),
            _DrawerItem(
              icon: Icons.insights_rounded,
              label: 'Input Laba Bersih',
              onTap: () {
                Navigator.pop(context);
                Future.delayed(const Duration(milliseconds: 300), () {
                  final cabangId = 'CB004';
                  final tanggal  = DateTime.now();
                  Navigator.pushNamed(
                    context,
                    '/input-laba',
                    arguments: {'idCabang': cabangId, 'tanggal': tanggal},
                  );
                });
              },
            ),

            const Divider(height: 24, indent: 16, endIndent: 16),

            _DrawerItem(
              icon: Icons.history_rounded,
              label: 'Log Aktivitas',
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LogPage())),
            ),

            const SizedBox(height: 8),

            _DrawerItem(
              icon: Icons.logout_rounded,
              label: 'Keluar',
              danger: true,
              onTap: () async {
                final supabase = Supabase.instance.client;
                final user = supabase.auth.currentUser;
                if (user != null) {
                  final userData = await supabase
                      .from('profiles')
                      .select('nama, role')
                      .eq('id', user.id)
                      .maybeSingle();

                  if (userData != null) {
                    final nama = userData['nama'];
                    final role = userData['role'];
                    await logService.addLog(
                      aktivitas: "Logout",
                      halaman: "Auth",
                      detail: "User $nama ($role) melakukan logout",
                    );
                  }
                }
                await supabase.auth.signOut();
                if (context.mounted) {
                  Navigator.pushReplacementNamed(context, '/login');
                }
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Color(0xFFFFC1CC), Colors.white],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 20),
                Wrap(
                  spacing: 20,
                  runSpacing: 16,
                  alignment: WrapAlignment.center,
                  children: List.generate(_navItems.length, (index) {
                    return _buildNavButton(index);
                  }),
                ),
                const SizedBox(height: 30),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: _buildContent(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================== BAGIAN DASHBOARD ==================
  Future<List<Map<String, dynamic>>> _fetchHPPFromSupabase() async {
    try {
      final supabase = Supabase.instance.client;

      var query = supabase
          .from('bahan_pokok')
          .select('tanggal, id_cabang, total')
          .order('tanggal', ascending: true) as PostgrestFilterBuilder;

      if (_startDate != null) {
        query = query.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
      }
      if (_endDate != null) {
        query = query.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
      }

      final response = await query;

      final aggregatedData = <String, double>{};
      for (var item in response) {
        final cabangId = item['id_cabang'];
        final totalHPP = (item['total'] ?? 0.0) * 1.0;
        aggregatedData[cabangId] = (aggregatedData[cabangId] ?? 0) + totalHPP;
      }

      return aggregatedData.entries.map((e) => {'id_cabang': e.key, 'total': e.value}).toList();
    } catch (e) {
      debugPrint("❌ Error fetch HPP: $e");
      return [];
    }
  }

  Widget _buildLaporanTab(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'id', symbol: 'Rp ', decimalDigits: 0);

    final labaRugi = currencyFormat.format(25000000);
    final investor = currencyFormat.format(5000000);
    final stokGudang = currencyFormat.format(12000000);

    return SingleChildScrollView(
      child: Column(
        children: [
          _buildLaporanCard(
            title: "Laporan Income per mato",
            subtitle: "Ringkasan pemasukan & pengeluaran",
            nominal: labaRugi,
            onDetailPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => const LaporanIncomeMato()));
            },
          ),
          _buildLaporanCard(
            title: "Laporan Laba Bersih",
            subtitle: "Mutasi laba bersih per hari",
            nominal: investor,
            onDetailPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => LaporanLBPage(idCabang: widget.idCabang)));
            },
          ),
          _buildLaporanCard(
            title: "Laporan Stok",
            subtitle: "Analisa pemakaian barang",
            nominal: stokGudang,
            onDetailPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => LaporanStok(idCabang: widget.idCabang)));
            },
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton(int index) {
    final isSelected = _selectedIndex == index;
    return SizedBox(
      width: 200,
      height: 45,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? const Color(0xFFFFC1CC) : Colors.white,
          foregroundColor: Colors.black,
          elevation: isSelected ? 4 : 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
        ),
        onPressed: () => setState(() => _selectedIndex = index),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(_navItems[index]['icon'], size: 20),
            const SizedBox(width: 8),
            Text(_navItems[index]['label'], style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }

  Widget _buildSalesChart(List<Map<String, dynamic>> data) {
    final List<BarChartGroupData> barGroups = [];
    final List<String> tanggalList = [];

    for (int i = 0; i < data.length; i++) {
      final item = data[i];
      final double y = (item['total_omzet'] ?? 0).toDouble();
      final String tanggal = item['tanggal'] ?? '';
      tanggalList.add(tanggal);

      barGroups.add(BarChartGroupData(x: i, barRods: [BarChartRodData(toY: y, color: Colors.green)]));
    }

    return AspectRatio(
      aspectRatio: 1.6,
      child: BarChart(
        BarChartData(
          barGroups: barGroups,
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (double value, TitleMeta meta) {
                  final int index = value.toInt();
                  if (index < 0 || index >= tanggalList.length) return const SizedBox.shrink();
                  final formatted = DateFormat('d MMM').format(DateTime.parse(tanggalList[index]));
                  if (index % 10 != 0) return const SizedBox.shrink();
                  return Text(formatted, style: const TextStyle(fontSize: 10));
                },
                reservedSize: 36,
                interval: 1,
              ),
            ),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: true)),
          ),
          borderData: FlBorderData(show: false),
          gridData: FlGridData(show: true),
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _applyDateFilter(List<Map<String, dynamic>> data) {
    return data.where((item) {
      try {
        final tanggal = DateTime.parse(item['tanggal']);
        if (_startDate != null && tanggal.isBefore(_startDate!)) return false;
        if (_endDate != null && tanggal.isAfter(_endDate!)) return false;
        return true;
      } catch (_) {
        return false;
      }
    }).toList();
  }

  Widget _buildOmzetLineChart(List<Map<String, dynamic>> data, {String filterType = 'all'}) {
    if (data.isEmpty) {
      return const Center(child: Text("Tidak ada data"));
    }

    final omzetPerTanggal = <String, double>{};
    for (var item in data) {
      final tanggal = item['tanggal'];
      final omzet = (item['total_omzet'] as num?)?.toDouble() ?? 0.0;
      omzetPerTanggal[tanggal] = (omzetPerTanggal[tanggal] ?? 0) + omzet;
    }

    final sortedKeys = omzetPerTanggal.keys.toList()..sort();
    final omzetValues = sortedKeys.map((k) => omzetPerTanggal[k]!).toList();

    final minValue = omzetValues.reduce((a, b) => a < b ? a : b);
    final maxValue = omzetValues.reduce((a, b) => a > b ? a : b);

    final chartMinY = (minValue * 0.2).clamp(0, double.infinity);
    final chartMaxY = maxValue * 1.2;

    final spots = List.generate(sortedKeys.length, (i) => FlSpot(i.toDouble(), omzetPerTanggal[sortedKeys[i]]!));

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withOpacity(0.1), width: 1),
      ),
      child: SizedBox(
        height: 300,
        child: LineChart(
          LineChartData(
            minX: -0.3,
            maxX: sortedKeys.length - 0.7,
            minY: chartMinY.toDouble(),
            maxY: chartMaxY.toDouble(),
            gridData: const FlGridData(show: false),
            titlesData: FlTitlesData(
              leftTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  reservedSize: 60,
                  getTitlesWidget: (value, meta) {
                    final yValues = omzetPerTanggal.values.toSet();
                    if (!yValues.contains(value)) return const SizedBox.shrink();

                    if (value >= 1000000) {
                      return Text("Rp ${(value / 1000000).toStringAsFixed(2)} jt", style: const TextStyle(fontSize: 11));
                    } else if (value >= 1000) {
                      return Text("Rp ${(value / 1000).toStringAsFixed(0)} rb", style: const TextStyle(fontSize: 11));
                    }
                    return Text("Rp ${value.toStringAsFixed(0)}", style: const TextStyle(fontSize: 11));
                  },
                ),
              ),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  interval: 1,
                  getTitlesWidget: (value, meta) {
                    final index = value.toInt();
                    if (index < 0 || index >= sortedKeys.length) return const SizedBox();
                    final distanceFromLeft = value - meta.min;
                    final distanceFromRight = meta.max - value;
                    if (distanceFromLeft < 0.1 || distanceFromRight < 0.1) return const SizedBox();
                    return Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(
                        DateFormat('dd MMM').format(DateTime.parse(sortedKeys[index])),
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                    );
                  },
                ),
              ),
              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
            borderData: FlBorderData(show: true, border: Border.all(color: Colors.black)),
            lineBarsData: [
              LineChartBarData(
                spots: spots,
                isCurved: false,
                color: Colors.blueGrey,
                barWidth: 3,
                dotData: const FlDotData(show: false),
              ),
              ...spots.map((spot) {
                return LineChartBarData(
                  spots: [FlSpot(spot.x, chartMinY.toDouble()), FlSpot(spot.x, spot.y)],
                  isCurved: false,
                  color: Colors.black.withOpacity(0.4),
                  barWidth: 2,
                  dashArray: [4, 4],
                  dotData: const FlDotData(show: false),
                );
              }).toList(),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _exportChartToPdf(GlobalKey chartKey) async {
    final pdf = pw.Document();
    final image = await WidgetWraper.wrapWidgetToImage(chartKey);

    if (image != null) {
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) => pw.Center(child: pw.Image(pw.MemoryImage(image))),
        ),
      );
      await Printing.layoutPdf(onLayout: (PdfPageFormat format) async => pdf.save());
    }
  }

  String _selectedOmzetFilter = 'all'; // all | month | 100days

  Future<List<Map<String, dynamic>>> _fetchOmzetFromSupabase() async {
    try {
      final supabase = Supabase.instance.client;
      final response =
      await supabase.from('rekap_omzet_harian').select('tanggal, total_omzet').order('tanggal', ascending: true);
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint("❌ Error fetch omzet: $e");
      return [];
    }
  }

  Widget _buildContent() {
    switch (_selectedIndex) {
      case 0:
        return SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 32),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Filter Tanggal', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _startDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                          );
                          if (picked != null) setState(() => _startDate = picked);
                        },
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            _startDate != null
                                ? 'Dari: ${DateFormat('dd MMM yyyy').format(_startDate!)}'
                                : 'Pilih Tanggal Awal',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: _endDate ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime.now(),
                          );
                          if (picked != null) setState(() => _endDate = picked);
                        },
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            _endDate != null
                                ? 'Sampai: ${DateFormat('dd MMM yyyy').format(_endDate!)}'
                                : 'Pilih Tanggal Akhir',
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(onPressed: () => setState(() {}), child: const Text('Tampilkan')),
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    _PresetChipDash(text: 'Semua Data', selected: _salesPreset == 'all', onTap: () => _applySalesPreset('all')),
                    _PresetChipDash(text: 'Bulan Ini', selected: _salesPreset == 'month', onTap: () => _applySalesPreset('month')),
                    _PresetChipDash(text: '100 Hari Terakhir', selected: _salesPreset == '100', onTap: () => _applySalesPreset('100')),
                  ],
                ),
                const SizedBox(height: 24),
                const Text('Grafik Sales', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchSales100Hari(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Text('Gagal memuat data sales: ${snapshot.error}');
                    }
                    final filteredData = _applyDateFilter(snapshot.data ?? []);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RepaintBoundary(key: _chartKeySales, child: _buildSalesChart(filteredData)),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () => _exportChartToPdf(_chartKeySales),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('Export Sales ke PDF'),
                        ),
                      ],
                    );
                  },
                ),
                const SizedBox(height: 32),
                const Text('Grafik HPP', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _fetchHPPFromSupabase(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Text('Gagal memuat HPP: ${snapshot.error}');
                    }
                    final allData = snapshot.data ?? [];
                    final filteredData = _applyDateFilter(allData);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RepaintBoundary(key: _chartKeyHPP, child: _buildOmzetLineChart(filteredData)),
                        const SizedBox(height: 12),
                        ElevatedButton.icon(
                          onPressed: () => _exportChartToPdf(_chartKeyHPP),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: const Text('Export HPP ke PDF'),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        );

      case 1:
        return _buildLaporanTab(context);

      case 2:
        return _buildMatoBoxList();

      case 3:
      // === REKAP TRANSAKSI: Mutasi ala LB — BAGIAN INI YANG VERTICAL SCROLL ===
        return Scrollbar(
          controller: _rtVBody,
          thumbVisibility: true,
          child: SingleChildScrollView(
            controller: _rtVBody,
            padding: const EdgeInsets.only(bottom: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Rekap Transaksi (Mutasi)',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                _rtFilterBar(),
                const SizedBox(height: 10),

                LayoutBuilder(
                  builder: (context, c) {
                    final minTotal  = _rtBaseWidths.reduce((a, b) => a + b);
                    final available = c.maxWidth - 24; // padding card
                    final totalW    = max(available, minTotal.toDouble());
                    final scale     = totalW / minTotal;
                    final widths    = _rtBaseWidths.map((w) => w * scale).toList();
                    final tableW    = widths.reduce((a, b) => a + b);

                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.35),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 14, offset: Offset(0, 6))],
                      ),
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                      child: Column(
                        children: [
                          // Header tabel (scroll HORIZONTAL)
                          Scrollbar(
                            controller: _rtHHeader,
                            thumbVisibility: true,
                            child: SingleChildScrollView(
                              controller: _rtHHeader,
                              scrollDirection: Axis.horizontal,
                              child: SizedBox(width: tableW, child: _rtBuildHeader(widths)),
                            ),
                          ),
                          const SizedBox(height: 8),

                          // Body tabel (scroll HORIZONTAL; vertikal ikut parent)
                          Scrollbar(
                            controller: _rtHBody,
                            thumbVisibility: true,
                            child: SingleChildScrollView(
                              controller: _rtHBody,
                              scrollDirection: Axis.horizontal,
                              child: SizedBox(
                                width: tableW,
                                child: _rtLoading
                                    ? const Padding(
                                  padding: EdgeInsets.all(24),
                                  child: Center(child: CircularProgressIndicator()),
                                )
                                    : (_rtRows.isEmpty
                                    ? _rtBuildPlaceholder(widths)
                                    : Column(
                                  children: List.generate(
                                    _rtRows.length,
                                        (i) => _rtDataRow(
                                      widths: widths,
                                      r: _rtRows[i],
                                      isFirst: i == 0,
                                    ),
                                  ),
                                )),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );

      default:
      // supaya switch SELALU mengembalikan widget
        return const SizedBox.shrink();
    }
  }

  Future<void> _applySalesPreset(String code) async {
    final now = DateTime.now();
    setState(() {
      _salesPreset = code;
      if (code == 'all') {
        _startDate = null;
        _endDate = null;
      } else if (code == 'month') {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = DateTime(now.year, now.month + 1, 0);
      } else if (code == '100') {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate = now;
      }
    });
  }

  // Format tanggal header dialog
  String _fmtTanggal(String iso) {
    try {
      final d = DateTime.parse(iso);
      return DateFormat('d MMM yyyy', 'id_ID').format(d);
    } catch (_) {
      return iso;
    }
  }

// Widget seksi grup pemasukan/pengeluaran dengan daftar per-jenis
  Widget _groupSection({
    required String title,
    required Map<String, int> items,
    required Color color,
    required IconData icon,
  }) {
    final total = items.values.fold<int>(0, (a, b) => a + b);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const Spacer(),
              Text(
                rupiah(total),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color),
              ),
            ],
          ),
          const SizedBox(height: 10),

          if (items.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 6),
              child: Text('Tidak ada data', style: TextStyle(color: Colors.black54)),
            )
          else
            ...items.entries.map(
                  (e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        e.key,
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                      ),
                    ),
                    Text(
                      rupiah(e.value),
                      style: TextStyle(fontWeight: FontWeight.w700, color: color),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

// ==== GANTI fungsi ini ====
  Future<void> _showDetailTransaksi(BuildContext context, String tanggalIso) async {
    final breakdown = await _fetchKategoriBreakdown(tanggalIso);
    final tanggal = DateTime.parse(tanggalIso);
    final judul = DateFormat('d MMM yyyy', 'id_ID').format(tanggal);

    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: const Color(0xFFEFF4EC),
        insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Detail Transaksi $judul',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),

                _groupSection(
                  title: 'pemasukan',
                  items: breakdown.pemasukan,
                  color: Colors.green.shade700,
                  icon: Icons.add_circle_rounded,
                ),
                _groupSection(
                  title: 'pengeluaran',
                  items: breakdown.pengeluaran,
                  color: Colors.red.shade700,
                  icon: Icons.remove_circle_rounded,
                ),

                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Tutup'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==== EDIT / DELETE dipakai ulang, ditambah refresh mutasi ====
  Future<void> _editKeteranganTransaksi(BuildContext context, String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final userProfile = await supabase.from('profiles').select('id_cabang, nama').eq('id', user.id).maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    final namaAdmin = userProfile?['nama'] ?? 'Admin';
    if (idCabang == null) return;

    final transaksi = await supabase
        .from('transaksi_harian')
        .select()
        .eq('id_cabang', idCabang)
        .eq('tanggal', tanggal)
        .limit(1)
        .maybeSingle();

    if (transaksi == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Detail tidak tersedia untuk data rekap.')),
      );
      return;
    }

    final TextEditingController keteranganController =
    TextEditingController(text: transaksi['keterangan'] ?? '');

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Keterangan'),
        content: TextField(
          controller: keteranganController,
          decoration: const InputDecoration(labelText: 'Keterangan baru'),
          maxLines: 3,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              final newKeterangan = keteranganController.text.trim();
              await supabase.from('transaksi_harian').update({'keterangan': newKeterangan}).eq('id', transaksi['id']);

              Navigator.of(context).pop();
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text('Keterangan berhasil diperbarui')));

              await logService.addLog(
                aktivitas: '$namaAdmin edit keterangan transaksi',
                halaman: 'Rekap Transaksi',
                detail: 'Tanggal: $tanggal',
              );

              setState(() {});
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteLaporan(BuildContext context, String tanggal) async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final userProfile = await supabase.from('profiles').select('id_cabang, nama').eq('id', user.id).maybeSingle();

    final idCabang = userProfile?['id_cabang'];
    final namaAdmin = userProfile?['nama'] ?? 'Admin';
    if (idCabang == null) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi'),
        content: const Text('Yakin ingin menghapus semua transaksi pada tanggal ini?'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Batal')),
          ElevatedButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Hapus')),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      await supabase.from('transaksi_harian').delete().eq('id_cabang', idCabang).eq('tanggal', tanggal);

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Transaksi berhasil dihapus')));

      await logService.addLog(
        aktivitas: '$namaAdmin delete transaksi',
        halaman: 'Rekap Transaksi',
        detail: 'Tanggal: $tanggal',
      );

      setState(() {});
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menghapus: $e')));
    }
  }
  // ====== MATO: dialog & helpers ======

  Future<int> _fetchIncomePerMatoValue() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return 0;

    final profile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) return 0;

    final today = DateTime.now();
    final result = await supabase
        .from('income_per_mato')
        .select('income_per_mato')
        .eq('id_cabang', idCabang)
        .lte('tanggal_awal', today.toIso8601String())
        .gte('tanggal_akhir', today.toIso8601String())
        .maybeSingle();

    return result?['income_per_mato'] ?? 0;
  }

  String _hitungPendapatan(String mata, String nilai) {
    final m = int.tryParse(mata) ?? 0;
    final n = int.tryParse(nilai) ?? 0;
    return (m * n).toString();
  }

  String _hitungTotalMingguan(String mata, String nilai, String servis) {
    final pendapatan = int.tryParse(_hitungPendapatan(mata, nilai)) ?? 0;
    final s = int.tryParse(servis) ?? 0;
    return (pendapatan + s).toString();
  }

  String _hitungHasil(String mata, String nilai, String pinjaman, String bonMakan, String bonGudang, String potAbsen) {
    final pendapatan = int.tryParse(_hitungPendapatan(mata, nilai)) ?? 0;
    final pot = (int.tryParse(pinjaman) ?? 0) +
        (int.tryParse(bonMakan) ?? 0) +
        (int.tryParse(bonGudang) ?? 0) +
        (int.tryParse(potAbsen) ?? 0);
    return (pendapatan - pot).toString();
  }

  String _hitungTotalHasil(
      String mata,
      String nilai,
      String pinjaman,
      String bonMakan,
      String bonGudang,
      String potAbsen,
      String servis,
      ) {
    final hasil = int.tryParse(_hitungHasil(mata, nilai, pinjaman, bonMakan, bonGudang, potAbsen)) ?? 0;
    final s = int.tryParse(servis) ?? 0;
    return (hasil + s).toString();
  }

  Widget _buildTextField(String label, TextEditingController controller, void Function(void Function()) setState) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  Widget _buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  void _showDetailMatoDialog(BuildContext context, Map<String, dynamic> pegawai) {
    int incomePerMato = 0;
    showDialog(
      context: context,
      builder: (context) {
        bool isEditing = false;

        final jabatanController = TextEditingController(text: pegawai['jabatan'] ?? '');
        final mataController = TextEditingController(text: (pegawai['skor_mato'] ?? 0).toString());
        int incomePerMato = 0;
        final pinjamanController = TextEditingController(text: (pegawai['pinjaman'] ?? 0).toString());
        final bonMakanController = TextEditingController(text: (pegawai['bon_makan'] ?? 0).toString());
        final bonGudangController = TextEditingController(text: (pegawai['bon_gudang'] ?? 0).toString());
        final potAbsenController = TextEditingController(text: (pegawai['pot_absen'] ?? 0).toString());
        final absenController = TextEditingController(text: (pegawai['absen'] ?? 0).toString());
        final servisController = TextEditingController(text: (pegawai['uang_servis'] ?? 0).toString());

        return StatefulBuilder(
          builder: (context, setState) {
            if (incomePerMato == 0) {
              _fetchIncomePerMatoValue().then((value) {
                setState(() => incomePerMato = value);
              });
            }
            return AlertDialog(
              backgroundColor: const Color(0xFFEFF1E8),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: Text('Detail Pegawai - ${pegawai['nama'] ?? '-'}'),
              content: SingleChildScrollView(
                child: isEditing
                    ? Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildTextField('Jabatan', jabatanController, setState),
                    _buildTextField('Mata', mataController, setState),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Income per Mato'),
                        Text(
                          'Rp $incomePerMato',
                          style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    _buildRow('Pendapatan', 'Rp ${_hitungPendapatan(mataController.text, incomePerMato.toString())}'),
                    const SizedBox(height: 20),
                    _buildTextField('Bon Makan', bonMakanController, setState),
                    _buildTextField('Bon Gudang', bonGudangController, setState),
                    _buildTextField('Pot Absen', potAbsenController, setState),
                    _buildTextField('Absen', absenController, setState),
                    _buildTextField('Uang Servis', servisController, setState),
                  ],
                )
                    : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildRow('Mata', mataController.text),
                    _buildRow('Nilai/Mata', 'Rp ${incomePerMato.toString()}'),
                    _buildRow('Pendapatan', 'Rp ${_hitungPendapatan(mataController.text, incomePerMato.toString())}'),
                    _buildRow('Pinjaman', 'Rp ${pinjamanController.text}'),
                    _buildRow('Bon Makan', 'Rp ${bonMakanController.text}'),
                    _buildRow('Bon Gudang', 'Rp ${bonGudangController.text}'),
                    _buildRow('Pot Absen', 'Rp ${potAbsenController.text}'),
                    _buildRow('Uang Servis', 'Rp ${servisController.text}'),
                    _buildRow('Total Mingguan', 'Rp ${_hitungTotalMingguan(mataController.text, incomePerMato.toString(), servisController.text)}'),
                    _buildRow('Hasil', 'Rp ${_hitungHasil(mataController.text, incomePerMato.toString(), pinjamanController.text, bonMakanController.text, bonGudangController.text, potAbsenController.text)}'),
                    _buildRow('Total Hasil', 'Rp ${_hitungTotalHasil(mataController.text, incomePerMato.toString(), pinjamanController.text, bonMakanController.text, bonGudangController.text, potAbsenController.text, servisController.text)}'),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Tutup', style: TextStyle(color: Colors.red))),
                isEditing
                    ? ElevatedButton.icon(
                  onPressed: () async {
                    final supabase = Supabase.instance.client;

                    final skor = int.tryParse(mataController.text) ?? 0;
                    final nilai = int.tryParse(incomePerMato.toString()) ?? 0;
                    final pendapatan = skor * nilai;

                    final potongan = (int.tryParse(pinjamanController.text) ?? 0) +
                        (int.tryParse(bonMakanController.text) ?? 0) +
                        (int.tryParse(bonGudangController.text) ?? 0) +
                        (int.tryParse(potAbsenController.text) ?? 0);

                    final uangServis = int.tryParse(servisController.text) ?? 0;
                    final totalMingguan = pendapatan + uangServis;
                    final hasil = pendapatan - potongan;
                    final totalHasil = hasil + uangServis;

                    try {
                      await supabase.from('profiles').update({
                        'jabatan': jabatanController.text,
                        'skor_mato': skor,
                        'nilai_per_mata': nilai,
                        'pendapatan': pendapatan,
                        'pinjaman': int.tryParse(pinjamanController.text) ?? 0,
                        'bon_makan': int.tryParse(bonMakanController.text) ?? 0,
                        'bon_gudang': int.tryParse(bonGudangController.text) ?? 0,
                        'pot_absen': int.tryParse(potAbsenController.text) ?? 0,
                        'absen': int.tryParse(absenController.text) ?? 0,
                        'uang_servis': uangServis,
                        'total_mingguan': totalMingguan,
                        'hasil': hasil,
                        'total_hasil': totalHasil,
                      }).eq('id', pegawai['id']);

                      // log
                      final user = Supabase.instance.client.auth.currentUser;
                      if (user != null) {
                        final userProfile = await supabase
                            .from('profiles')
                            .select('nama')
                            .eq('id', user.id)
                            .maybeSingle();

                        final namaAdmin = userProfile?['nama'] ?? 'Admin';
                        final namaPegawai = pegawai['nama'] ?? '-';
                        final tanggal = DateFormat('yyyy-MM-dd').format(DateTime.now());

                        await logService.addLog(
                          aktivitas: '$namaAdmin melakukan pembaruan data pegawai $namaPegawai',
                          halaman: 'Detail Pegawai',
                          detail: 'Tanggal: $tanggal',
                        );
                      }

                      if (context.mounted) {
                        Navigator.of(context).pop();
                        ScaffoldMessenger.of(context)
                            .showSnackBar(const SnackBar(content: Text("Berhasil update data pegawai")));
                      }
                      setState(() {});
                    } catch (e) {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(SnackBar(content: Text("Gagal update data: $e")));
                    }
                  },
                  icon: const Icon(Icons.save),
                  label: const Text('Simpan Perubahan'),
                )
                    : ElevatedButton.icon(
                  onPressed: () => setState(() => isEditing = true),
                  icon: const Icon(Icons.edit),
                  label: const Text('Perbarui data'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // Widget: daftar pegawai (Mato)
  final TextEditingController _searchController = TextEditingController();
  String _sortOption = 'Tertinggi';

  Widget _buildMatoBoxList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Mato Pegawai', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Cari nama pegawai...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(width: 12),
            DropdownButton<String>(
              value: _sortOption,
              items: ['Tertinggi', 'Terendah'].map((option) {
                return DropdownMenuItem(value: option, child: Text('Sort by $option'));
              }).toList(),
              onChanged: (value) => setState(() => _sortOption = value ?? 'Tertinggi'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        FutureBuilder<List<Map<String, dynamic>>>(
          future: _fetchPegawaiFromSupabase(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Terjadi kesalahan: ${snapshot.error}'));
            }

            List<Map<String, dynamic>> pegawaiList = snapshot.data ?? [];

            final searchQuery = _searchController.text.toLowerCase();
            pegawaiList =
                pegawaiList.where((e) => (e['nama'] ?? '').toString().toLowerCase().contains(searchQuery)).toList();

            pegawaiList.sort((a, b) {
              final aVal = a['skor_mato'] ?? 0;
              final bVal = b['skor_mato'] ?? 0;
              return _sortOption == 'Tertinggi' ? bVal.compareTo(aVal) : aVal.compareTo(bVal);
            });

            return SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: pegawaiList.map((pegawai) {
                  return Container(
                    width: 240,
                    height: 180,
                    margin: const EdgeInsets.only(right: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 4)],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(pegawai['nama'] ?? '-', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        Text(pegawai['jabatan'] ?? '-', style: const TextStyle(fontSize: 14)),
                        const Spacer(),
                        Text(
                          "Poin Mato ${pegawai['skor_mato'] ?? 0}",
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.orange),
                        ),
                        const SizedBox(height: 8),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () => _showDetailMatoDialog(context, pegawai),
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade100),
                            child: const Text('Detail', style: TextStyle(color: Colors.green)),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            );
          },
        ),
      ],
    );
  }
}

// ========== HELPER ==========
class WidgetWraper {
  static Future<Uint8List?> wrapWidgetToImage(GlobalKey key) async {
    try {
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      final image = await boundary?.toImage(pixelRatio: 2.0);
      final byteData = await image?.toByteData(format: ui.ImageByteFormat.png);
      return byteData?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }
}

class _PresetChipDash extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;
  const _PresetChipDash({
    required this.text,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFE4E9) : Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
  }
}

// ====== Reusable kecil ala LaporanLB ======
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _Breakdown {
  final Map<String, int> pemasukan;
  final Map<String, int> pengeluaran;
  _Breakdown(this.pemasukan, this.pengeluaran);
}

class _FancyDrawerHeader extends StatelessWidget {
  final String namaUsaha;
  final String email;
  final String role;
  final String cabang;
  final String? photoUrl;
  final VoidCallback? onTapEditUsaha;
  final VoidCallback? onTapSettings;

  const _FancyDrawerHeader({
    required this.namaUsaha,
    required this.email,
    required this.role,
    required this.cabang,
    this.photoUrl,
    this.onTapEditUsaha,
    this.onTapSettings,
  });

  String _initialsFrom(String s) {
    final parts = s.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return 'U';
    final first = parts.first.isNotEmpty ? parts.first[0] : '';
    final last  = parts.length > 1 && parts.last.isNotEmpty ? parts.last[0] : '';
    return (first + last).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top; // safe-area
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(24),
        bottomRight: Radius.circular(24),
      ),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFC1CC), Colors.white],
          ),
        ),
        // ⬇️ PADDING dinamis: tak akan overflow
        padding: EdgeInsets.fromLTRB(16, top + 16, 12, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min, // <-- biar setinggi konten
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: const Color(0xFF2D2D2D),
                  backgroundImage: (photoUrl != null && photoUrl!.isNotEmpty)
                      ? NetworkImage(photoUrl!)
                      : null,
                  child: (photoUrl == null || photoUrl!.isEmpty)
                      ? Text(
                    _initialsFrom(namaUsaha),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                    ),
                  )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              namaUsaha,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                letterSpacing: .2,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          InkWell(
                            onTap: onTapEditUsaha,
                            borderRadius: BorderRadius.circular(20),
                            child: const Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(Icons.edit, size: 18),
                            ),
                          ),
                          const SizedBox(width: 4),
                          InkWell(
                            onTap: onTapSettings,
                            borderRadius: BorderRadius.circular(20),
                            child: const Padding(
                              padding: EdgeInsets.all(4.0),
                              child: Icon(Icons.settings, size: 18),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.black54,
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // chip2 – taruh dalam scroll horizontal biar aman jika panjang
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _badge(role, color: const Color(0xFF22313F)),
                  const SizedBox(width: 8),
                  _chip(icon: Icons.location_on_rounded, label: cabang),
                ],
              ),
            ),

            const SizedBox(height: 12),

            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.55),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black.withOpacity(0.06)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: const [
                  Icon(Icons.verified_user, size: 16, color: Colors.black87),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Akun aktif – akses admin cabang',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(String text, {required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: .3,
        ),
      ),
    );
  }

  Widget _chip({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black.withOpacity(0.10)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.black87),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, letterSpacing: .2),
          ),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;
  final bool danger;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final bg = active ? const Color(0xFFFFE4E9) : Colors.white;
    final fg = danger ? Colors.red : Colors.black87;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Material(
        color: bg,
        borderRadius: BorderRadius.circular(14),
        elevation: active ? 2 : 0,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Icon(icon, color: danger ? Colors.red : Colors.black87),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: fg,
                    ),
                  ),
                ),
                Icon(Icons.chevron_right_rounded,
                    color: danger ? Colors.red : Colors.black38),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

