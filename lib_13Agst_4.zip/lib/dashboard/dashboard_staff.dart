import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// ===== Helper Rupiah =====
final NumberFormat _rupiahFmt =
NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
String rupiah(num v) => _rupiahFmt.format(v);

class DashboardStaff extends StatefulWidget {
  const DashboardStaff({super.key});

  @override
  State<DashboardStaff> createState() => _DashboardStaffState();
}

class _DashboardStaffState extends State<DashboardStaff> {
  final supabase = Supabase.instance.client;

  // Info user & usaha
  String? _namaUsaha;
  String? _namaCabang;
  String? staffEmail;

  // Filter tanggal utk grafik total_hasil
  DateTime? _startDate;
  DateTime? _endDate;
  String _preset = 'all'; // all | month | 100

  // Export PDF (seluruh halaman)
  final GlobalKey _pageKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _loadNamaUsaha();
    _loadStaffInfo();
  }

  // ================== LOAD STATIC ==================
  Future<void> _loadNamaUsaha() async {
    try {
      final row = await supabase
          .from('app_settings')
          .select('value')
          .eq('key', 'nama_usaha')
          .maybeSingle();
      if (!mounted) return;
      setState(() => _namaUsaha = (row?['value'] as String?)?.trim());
    } catch (e) {
      debugPrint('load nama_usaha error: $e');
    }
  }

  Future<void> _loadStaffInfo() async {
    final user = supabase.auth.currentUser;
    if (user == null) return;
    try {
      final row = await supabase
          .from('profiles')
          .select('email, cabang!inner(nama_cabang)')
          .eq('id', user.id)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        staffEmail = (row?['email'] ?? user.email)?.toString();
        _namaCabang =
            ((row?['cabang']?['nama_cabang']) ?? row?['nama_cabang'])?.toString();
      });
    } catch (e) {
      debugPrint('load staff info error: $e');
    }
  }

  // ================== DATA: “Pendapatan Saya” (row profiles) ==================
  Future<Map<String, dynamic>?> _fetchMyIncomeRow() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;

    final row = await supabase
        .from('profiles')
        .select('''
          id, nama, jabatan,
          pendapatan, hasil, total_hasil, total_mingguan,
          skor_mato, nilai_per_mata, uang_servis,
          pinjaman, bon_makan, bon_gudang, pot_absen,
          updated_at
        ''')
        .eq('id', user.id)
        .maybeSingle();

    return row;
  }

  // ================== DATA: Series total_hasil (grafik) ==================
  String _iso(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

  /// 1) `riwayat_total_hasil(user_id, tanggal, total_hasil)`
  /// 2) fallback: satu titik dari `profiles.total_hasil` + `profiles.updated_at`
  Future<List<Map<String, dynamic>>> _fetchTotalHasilSeries() async {
    final user = supabase.auth.currentUser;
    if (user == null) return [];

    try {
      var qb = supabase
          .from('riwayat_total_hasil')
          .select('tanggal, total_hasil')
          .eq('user_id', user.id)
          .order('tanggal', ascending: true)
      as PostgrestFilterBuilder;

      if (_startDate != null) qb = qb.gte('tanggal', _iso(_startDate!));
      if (_endDate != null) qb = qb.lte('tanggal', _iso(_endDate!));

      final res = await qb;
      return List<Map<String, dynamic>>.from(res);
    } catch (e) {
      debugPrint('riwayat_total_hasil not available, fallback -> profiles ($e)');
      try {
        final r = await supabase
            .from('profiles')
            .select('total_hasil, updated_at')
            .eq('id', user.id)
            .maybeSingle();
        if (r == null) return [];

        final String iso =
        (r['updated_at']?.toString() ?? DateTime.now().toIso8601String());
        final row = {
          'tanggal': iso.substring(0, 10),
          'total_hasil': (r['total_hasil'] as num?) ?? 0,
        };

        final dt = DateTime.tryParse((row['tanggal'] ?? '').toString());
        final okStart =
            _startDate == null || (dt != null && !dt.isBefore(_startDate!));
        final okEnd =
            _endDate == null || (dt != null && !dt.isAfter(_endDate!));
        return (okStart && okEnd) ? [row] : [];
      } catch (e2) {
        debugPrint('fallback profiles failed: $e2');
        return [];
      }
    }
  }

  // ================== EXPORT PDF (HALAMAN PENUH) ==================
  Future<void> _exportPageToPdf() async {
    try {
      final boundary =
      _pageKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      final image = await boundary?.toImage(pixelRatio: 2.0);
      final byteData = await image?.toByteData(format: ui.ImageByteFormat.png);
      final pngBytes = byteData?.buffer.asUint8List();
      if (pngBytes == null) return;

      final pdf = pw.Document();
      final img = pw.MemoryImage(pngBytes);
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (_) => pw.Center(child: pw.Image(img, fit: pw.BoxFit.contain)),
        ),
      );
      await Printing.layoutPdf(onLayout: (f) async => pdf.save());
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Gagal export PDF: $e')));
    }
  }

  // ================== FILTER UI HELPERS ==================
  Future<void> _pickDate({required bool isStart}) async {
    final now = DateTime.now();
    final init = isStart ? (_startDate ?? now) : (_endDate ?? _startDate ?? now);
    final picked = await showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 1, 12, 31),
      builder: (ctx, child) =>
          Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );
    if (picked == null) return;
    setState(() {
      if (isStart) {
        _startDate = picked;
        if (_endDate != null && _endDate!.isBefore(_startDate!)) {
          _endDate = _startDate;
        }
      } else {
        _endDate = picked;
        if (_startDate != null && _startDate!.isAfter(_endDate!)) {
          _startDate = _endDate;
        }
      }
    });
  }

  void _clearDates() {
    setState(() {
      _startDate = null;
      _endDate = null;
      _preset = 'all';
    });
  }

  void _applyPreset(String code) {
    final now = DateTime.now();
    setState(() {
      _preset = code;
      if (code == 'all') {
        _startDate = null;
        _endDate = null;
      } else if (code == 'month') {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = DateTime(now.year, now.month + 1, 0);
      } else if (code == '100') {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate = now;
      }
    });
  }

  // ================== BUILD ==================
  @override
  Widget build(BuildContext context) {
    final namaUsahaUpper = (_namaUsaha ?? 'NAMA USAHA').toUpperCase();
    final namaCabangUpper = (_namaCabang ?? '[NAMA CABANG]').toUpperCase();

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Builder(
                  builder: (context) => IconButton(
                    icon: const Icon(Icons.menu, size: 34, color: Colors.black),
                    onPressed: () => Scaffold.of(context).openDrawer(),
                  ),
                ),
                const SizedBox(width: 16),
                // Kiri: logo + nama usaha (dinamis)
                Row(
                  children: [
                    Image.asset('assets/logobg.png', height: 85),
                    const SizedBox(width: 10),
                    Text(
                      namaUsahaUpper,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 30,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                // Kanan: STAF {NAMA USAHA} + cabang
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.refresh, size: 20),
                          tooltip: 'Refresh',
                          onPressed: _refreshPage,
                        ),
                        Text(
                          'STAF $namaUsahaUpper',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                    // kalau di file kamu ada baris nama cabang merah, biarkan tetap:
                    if (_namaCabang != null)
                      Text(
                        (_namaCabang ?? '').toUpperCase(),
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Colors.red,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),

      // Drawer ringkas: hanya Logout
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            _FancyDrawerHeader(
              namaUsaha: namaUsahaUpper,
              email: staffEmail ?? 'Memuat email…',
              role: 'STAF',
              cabang: namaCabangUpper,
              photoUrl:
              Supabase.instance.client.auth.currentUser?.userMetadata?['avatar_url'],
              onTapEditUsaha: null,
              onTapSettings: null,
            ),
            const Divider(height: 24, indent: 16, endIndent: 16),
            _DrawerItem(
              icon: Icons.logout_rounded,
              label: 'Keluar',
              danger: true,
              onTap: () async {
                await supabase.auth.signOut();
                if (context.mounted) {
                  Navigator.pushReplacementNamed(context, '/login');
                }
              },
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),

      body: Stack(
        children: [
          // background
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Color(0xFFFFD1D1), Colors.white],
                ),
              ),
            ),
          ),

          // PAGE CONTENT (dibungkus utk export PDF)
          SafeArea(
            child: RepaintBoundary(
              key: _pageKey,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ===== Filter Tanggal =====
                    const Text('Filter Tanggal',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => _pickDate(isStart: true),
                            borderRadius: BorderRadius.circular(40),
                            child: _DatePill(
                              label: 'Tanggal Awal',
                              value: _startDate == null
                                  ? '—'
                                  : DateFormat('d MMM yyyy', 'id_ID').format(_startDate!),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: InkWell(
                            onTap: () => _pickDate(isStart: false),
                            borderRadius: BorderRadius.circular(40),
                            child: _DatePill(
                              label: 'Tanggal Akhir',
                              value: _endDate == null
                                  ? '—'
                                  : DateFormat('d MMM yyyy', 'id_ID').format(_endDate!),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        OutlinedButton(
                          onPressed: _clearDates,
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.black, width: 1),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40),
                            ),
                          ),
                          child: const Text('Clear'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _PresetChip(
                          text: 'Semua Data',
                          selected: _preset == 'all',
                          onTap: () => _applyPreset('all'),
                        ),
                        _PresetChip(
                          text: 'Bulan Ini',
                          selected: _preset == 'month',
                          onTap: () => _applyPreset('month'),
                        ),
                        _PresetChip(
                          text: '100 Hari Terakhir',
                          selected: _preset == '100',
                          onTap: () => _applyPreset('100'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: ElevatedButton.icon(
                        onPressed: _exportPageToPdf,
                        icon: const Icon(Icons.picture_as_pdf),
                        label: const Text('Export Halaman ke PDF'),
                      ),
                    ),
                    const SizedBox(height: 18),

                    // ====== PENDAPATAN SAYA (konsep awal) ======
                    FutureBuilder<Map<String, dynamic>?>(
                      future: _fetchMyIncomeRow(),
                      builder: (context, snap) {
                        if (snap.connectionState == ConnectionState.waiting) {
                          return const Padding(
                            padding: EdgeInsets.all(24.0),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        if (snap.hasError) {
                          return Text('Gagal memuat data: ${snap.error}');
                        }
                        final row = snap.data;
                        if (row == null) {
                          return const Text('Data pendapatan tidak ditemukan');
                        }

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Pendapatan Saya',
                                style: TextStyle(
                                    fontSize: 22, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 12),
                            _summaryCard(row),
                            const SizedBox(height: 18),
                            _detailBreakdown(row),
                          ],
                        );
                      },
                    ),

                    const SizedBox(height: 22),

                    // ====== GRAFIK: hanya Total Hasil ======
                    FutureBuilder<List<Map<String, dynamic>>>(
                      future: _fetchTotalHasilSeries(),
                      builder: (context, snap) {
                        if (snap.connectionState == ConnectionState.waiting) {
                          return const Center(
                            child: Padding(
                              padding: EdgeInsets.all(24.0),
                              child: CircularProgressIndicator(),
                            ),
                          );
                        }
                        if (snap.hasError) {
                          return Text('Gagal memuat grafik: ${snap.error}');
                        }
                        final data = snap.data ?? [];
                        final lastVal = (data.isNotEmpty)
                            ? (data.last['total_hasil'] as num?) ?? 0
                            : 0;

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _summaryTotalHasil(lastVal),
                            const SizedBox(height: 16),
                            const Text('Grafik Total Hasil',
                                style:
                                TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 8),
                            _buildTotalHasilLineChart(data),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ================= refresh featured ====================
  Future<void> _refreshPage() async {
    // muat ulang data statis header
    await Future.wait([
      _loadNamaUsaha(),
      _loadStaffInfo(),
    ]);

    if (!mounted) return;
    // rebuild agar FutureBuilder memanggil ulang _fetch...()
    setState(() {});

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Berhasil refresh halaman')),
    );
  }

  // ====== Summary (konsep awal) ======
  Widget _summaryCard(Map<String, dynamic> row) {
    final pendapatan = (row['pendapatan'] as num?) ?? 0;
    final servis = (row['uang_servis'] as num?) ?? 0;
    final potongan = ((row['pinjaman'] as num?) ?? 0) +
        ((row['bon_makan'] as num?) ?? 0) +
        ((row['bon_gudang'] as num?) ?? 0) +
        ((row['pot_absen'] as num?) ?? 0);
    final totalHasil = (row['total_hasil'] as num?) ?? (pendapatan - potongan + servis);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          _summaryItem('Pendapatan', rupiah(pendapatan), Icons.trending_up_rounded),
          const SizedBox(width: 12),
          _summaryItem('Potongan', rupiah(potongan),
              Icons.remove_circle_outline_rounded),
          const SizedBox(width: 12),
          _summaryItem('Servis', rupiah(servis), Icons.miscellaneous_services_rounded),
          const SizedBox(width: 12),
          _summaryItem('Total Hasil', rupiah(totalHasil), Icons.summarize_rounded,
              emphasize: true),
        ],
      ),
    );
  }

  Widget _summaryItem(String title, String value, IconData icon,
      {bool emphasize = false}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: emphasize ? const Color(0xFFFFE4E9) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.black.withOpacity(.08)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Icon(icon, size: 16), const SizedBox(width: 6), Text(title)]),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }

  Widget _detailBreakdown(Map<String, dynamic> row) {
    final skor = (row['skor_mato'] as num?) ?? 0;
    final nilai = (row['nilai_per_mata'] as num?) ?? 0;
    final pendapatan = (row['pendapatan'] as num?) ?? (skor * nilai);
    final pinjaman = (row['pinjaman'] as num?) ?? 0;
    final bonMakan = (row['bon_makan'] as num?) ?? 0;
    final bonGudang = (row['bon_gudang'] as num?) ?? 0;
    final potAbsen = (row['pot_absen'] as num?) ?? 0;
    final servis = (row['uang_servis'] as num?) ?? 0;
    final totalMingguan = (row['total_mingguan'] as num?) ?? (pendapatan + servis);
    final hasil =
        (row['hasil'] as num?) ?? (pendapatan - (pinjaman + bonMakan + bonGudang + potAbsen));
    final totalHasil = (row['total_hasil'] as num?) ?? (hasil + servis);

    final updatedAt = () {
      final raw = (row['updated_at'])?.toString();
      if (raw == null) return '—';
      try {
        return DateFormat('dd MMM yyyy HH:mm', 'id_ID')
            .format(DateTime.parse(raw).toLocal());
      } catch (_) {
        return '—';
      }
    }();

    Widget line(String label, num value, {bool bold = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Text(
            rupiah(value),
            style:
            TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w600),
          ),
        ],
      ),
    );

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Rincian Pendapatan',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: Text('Skor Mato: $skor')),
              Expanded(child: Text('Nilai/Mata: ${rupiah(nilai)}')),
              Expanded(child: Text('Terakhir update: $updatedAt')),
            ],
          ),
          const Divider(height: 22),
          line('Pendapatan', pendapatan),
          line('Pinjaman', pinjaman),
          line('Bon Makan', bonMakan),
          line('Bon Gudang', bonGudang),
          line('Potongan Absen', potAbsen),
          line('Uang Servis', servis),
          const Divider(height: 22),
          line('Total Mingguan', totalMingguan, bold: true),
          line('Hasil', hasil, bold: true),
          line('Total Hasil', totalHasil, bold: true),
        ],
      ),
    );
  }

  // ====== Summary kecil: Total Hasil terakhir (untuk grafik) ======
  Widget _summaryTotalHasil(num totalHasil) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.8),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(.06)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.savings_rounded),
          const SizedBox(width: 10),
          const Text('Total Hasil Terakhir',
              style: TextStyle(fontWeight: FontWeight.w700)),
          const Spacer(),
          Text(rupiah(totalHasil),
              style:
              const TextStyle(fontWeight: FontWeight.w800, color: Colors.black)),
        ],
      ),
    );
  }

  // ====== Line chart total_hasil ======
  Widget _buildTotalHasilLineChart(List<Map<String, dynamic>> data) {
    if (data.isEmpty) {
      return Container(
        height: 260,
        alignment: Alignment.center,
        child: const Text('Tidak ada data'),
      );
    }

    // sort & map
    data.sort((a, b) => a['tanggal'].toString().compareTo(b['tanggal'].toString()));
    final tanggal = <String>[];
    final spots = <FlSpot>[];
    for (int i = 0; i < data.length; i++) {
      tanggal.add(data[i]['tanggal'].toString());
      final y = ((data[i]['total_hasil'] as num?) ?? 0).toDouble();
      spots.add(FlSpot(i.toDouble(), y));
    }

    final ys = spots.map((e) => e.y).toList();
    final minY = ys.reduce((a, b) => a < b ? a : b);
    final maxY = ys.reduce((a, b) => a > b ? a : b);
    final chartMinY = (minY * 0.8).clamp(0, double.infinity).toDouble();
    final chartMaxY = (maxY * 1.2).clamp(1, double.infinity).toDouble();

    // tampilkan ~8 label (plus awal & akhir)
    final step = (spots.length <= 8) ? 1 : (spots.length / 8).ceil();

    return Container(
      height: 300,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withOpacity(0.1)),
      ),
      child: LineChart(
        LineChartData(
          // beri jarak kiri/kanan
          minX: -0.3,
          maxX: (spots.length - 1).toDouble() + 0.3,
          minY: chartMinY,
          maxY: chartMaxY,

          gridData: const FlGridData(show: false),
          borderData: FlBorderData(show: true, border: Border.all(color: Colors.black)),

          titlesData: FlTitlesData(
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)), // tetap disembunyikan
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: 1,
                reservedSize: 34,
                getTitlesWidget: (value, meta) {
                  final i = value.toInt();
                  if (i < 0 || i >= tanggal.length) return const SizedBox.shrink();

                  // ringkas label: tampilkan setiap 'step', plus indeks pertama & terakhir
                  final isEdge = (i == 0 || i == tanggal.length - 1);
                  if (!isEdge && (i % step != 0)) return const SizedBox.shrink();

                  final dt = DateTime.tryParse(tanggal[i]);
                  final label = (dt == null)
                      ? tanggal[i]
                      : DateFormat('dd MMM', 'id_ID').format(dt);

                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      label,
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
                    ),
                  );
                },
              ),
            ),
          ),

          // tooltip nominal + tanggal
          lineTouchData: LineTouchData(
            handleBuiltInTouches: true,
            touchTooltipData: LineTouchTooltipData(
              getTooltipColor: (barSpot) => Colors.blueGrey.shade600,
              tooltipPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              getTooltipItems: (touched) => touched.map((s) {
                final idx = s.x.round().clamp(0, tanggal.length - 1);
                final tgl = DateFormat('dd MMM', 'id_ID')
                    .format(DateTime.parse(tanggal[idx]));
                return LineTooltipItem(
                  '${rupiah(s.y)}\n$tgl',
                  const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                );
              }).toList(),
            ),
          ),

          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: false,
              barWidth: 3,
              color: Colors.blueGrey,
              dotData: const FlDotData(show: false),
            ),
          ],
        ),
      ),
    );
  }
}

/// ===================== Reusable kecil (preset & date pill) =====================
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final bool selected;
  final VoidCallback onTap;
  const _PresetChip({
    required this.text,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFE4E9) : Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
  }
}

/// ===================== Drawer Components =====================
class _FancyDrawerHeader extends StatelessWidget {
  final String namaUsaha;
  final String email;
  final String role;
  final String cabang;
  final String? photoUrl;
  final VoidCallback? onTapEditUsaha;
  final VoidCallback? onTapSettings;

  const _FancyDrawerHeader({
    required this.namaUsaha,
    required this.email,
    required this.role,
    required this.cabang,
    this.photoUrl,
    this.onTapEditUsaha,
    this.onTapSettings,
  });

  String _initialsFrom(String s) {
    final parts = s.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty) return 'U';
    final first = parts.first.isNotEmpty ? parts.first[0] : '';
    final last = parts.length > 1 && parts.last.isNotEmpty ? parts.last[0] : '';
    return (first + last).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(24),
        bottomRight: Radius.circular(24),
      ),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFFFC1CC), Colors.white],
          ),
        ),
        padding: EdgeInsets.fromLTRB(16, top + 16, 12, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: const Color(0xFF2D2D2D),
                  backgroundImage:
                  (photoUrl != null && photoUrl!.isNotEmpty) ? NetworkImage(photoUrl!) : null,
                  child: (photoUrl == null || photoUrl!.isEmpty)
                      ? Text(
                    _initialsFrom(namaUsaha),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                    ),
                  )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              namaUsaha,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                letterSpacing: .2,
                              ),
                            ),
                          ),
                          if (onTapEditUsaha != null) ...[
                            const SizedBox(width: 6),
                            InkWell(
                              onTap: onTapEditUsaha,
                              borderRadius: BorderRadius.circular(20),
                              child: const Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Icon(Icons.edit, size: 18),
                              ),
                            ),
                          ],
                          if (onTapSettings != null) ...[
                            const SizedBox(width: 4),
                            InkWell(
                              onTap: onTapSettings,
                              borderRadius: BorderRadius.circular(20),
                              child: const Padding(
                                padding: EdgeInsets.all(4.0),
                                child: Icon(Icons.settings, size: 18),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.black54, fontSize: 12.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _badge(role, color: const Color(0xFF22313F)),
                  const SizedBox(width: 8),
                  _chip(icon: Icons.location_on_rounded, label: cabang),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.55),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black.withOpacity(0.06)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: const Row(
                children: [
                  Icon(Icons.verified_user, size: 16, color: Colors.black87),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Akun aktif – akses staff cabang',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _badge(String text, {required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration:
      BoxDecoration(color: color, borderRadius: BorderRadius.circular(999)),
      child: Text(
        text,
        style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: .3),
      ),
    );
  }

  Widget _chip({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black.withOpacity(0.10)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.black87),
          const SizedBox(width: 6),
          Text(label,
              style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                  letterSpacing: .2)),
        ],
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool danger;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final fg = danger ? Colors.red : Colors.black87;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Icon(icon, color: fg),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(fontWeight: FontWeight.w600, color: fg),
                  ),
                ),
                Icon(Icons.chevron_right_rounded,
                    color: danger ? Colors.red : Colors.black38),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
