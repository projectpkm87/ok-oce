import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LaporanIncomeMato extends StatefulWidget {
  const LaporanIncomeMato({super.key});

  @override
  State<LaporanIncomeMato> createState() => _LaporanIncomeMatoState();
}

class _LaporanIncomeMatoState extends State<LaporanIncomeMato> {
  DateTime? _startDate;
  DateTime? _endDate;
  bool _showInfo = false;

  double _labaBersih = 0;
  int _totalMato = 0;

  Future<void> _selectDate(BuildContext context, bool isStart) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
        } else {
          _endDate = picked;
        }
      });
      if (_startDate != null && _endDate != null) {
        await _fetchData();
      }
    }
  }

  Future<void> _simpanKeSupabase() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    if (_startDate == null || _endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pilih tanggal terlebih dahulu")),
      );
      return;
    }

    final profile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) return;

    final bagianKaryawan = (_labaBersih / 2).round();
    final bagianDireksi = (_labaBersih / 2).round();
    final incomePerMato = _totalMato > 0 ? (bagianKaryawan / _totalMato).round() : 0;

    await supabase.from('income_per_mato').insert({
      'id_cabang': idCabang,
      'tanggal_awal': DateFormat('yyyy-MM-dd').format(_startDate!),
      'tanggal_akhir': DateFormat('yyyy-MM-dd').format(_endDate!),
      'total_laba_bersih': _labaBersih.round(),
      'bagian_karyawan': bagianKaryawan,
      'bagian_direksi': bagianDireksi,
      'total_mato': _totalMato,
      'income_per_mato': incomePerMato,
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Laporan berhasil disimpan")),
    );
  }

  Future<void> _fetchData() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;

    final profile = await supabase
        .from('profiles')
        .select('id_cabang')
        .eq('id', user.id)
        .maybeSingle();

    final idCabang = profile?['id_cabang'];
    if (idCabang == null) return;

    final labaResp = await supabase
        .from('laba_bersih')
        .select('total_laba_bersih')
        .eq('id_cabang', idCabang)
        .gte('tanggal', _startDate!.toIso8601String())
        .lte('tanggal', _endDate!.toIso8601String());

    double totalLaba = 0;
    for (var row in labaResp) {
      totalLaba += double.tryParse(row['total_laba_bersih'].toString()) ?? 0;
    }

    final matoResp = await supabase
        .from('profiles')
        .select('skor_mato')
        .eq('id_cabang', idCabang);

    int totalMato = 0;
    for (var row in matoResp) {
      totalMato += (row['skor_mato'] as num?)?.toInt() ?? 0;
    }

    setState(() {
      _labaBersih = totalLaba;
      _totalMato = totalMato;
    });
  }

  void _clearDates() {
    setState(() {
      _startDate = null;
      _endDate = null;
      _labaBersih = 0;
      _totalMato = 0;
    });
  }

  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _startDate ?? DateTime(now.year, now.month, 1),
      end: _endDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2024, 1, 1),
      lastDate: now,
      initialDateRange: initial,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(useMaterial3: false),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate   = picked.end;
      });
      await _fetchData();
    }
  }

  Future<void> _applyPreset(String code) async {
    final now = DateTime.now();

    if (code == 'all') {
      setState(() {
        _startDate = DateTime(2024, 1, 1);
        _endDate = now;
      });
    } else if (code == 'month') {
      setState(() {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = DateTime(now.year, now.month + 1, 0);
      });
    } else if (code == '100') {
      setState(() {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate = now;
      });
    }

    await _fetchData();
  }

  @override
  Widget build(BuildContext context) {
    final formatCurrency = NumberFormat.currency(
        locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
    final bagianKaryawan = _labaBersih / 2;
    final bagianDireksi = _labaBersih / 2;
    final incomePerMato = _totalMato > 0 ? bagianKaryawan / _totalMato : 0;

    final fmtChip = DateFormat('d MMM yyyy', 'id_ID');

    return Scaffold(
      extendBodyBehindAppBar: false,
      appBar: AppBar(
        backgroundColor: const Color(0xFFFFC1CC),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'Laporan Income per mato',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFC1CC), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Tanggal (rentang + chip + preset)

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Bar atas: Rentang & Clear
                            Row(
                              children: [
                                const Text(
                                  'Tanggal (Rentang)',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                const Spacer(),
                                ElevatedButton.icon(
                                  onPressed: _openRangePicker,
                                  icon: const Icon(Icons.date_range, size: 18),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFFFFE4E9),
                                    foregroundColor: Colors.black,
                                    elevation: 0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(40),
                                      side: const BorderSide(color: Colors.black, width: 1),
                                    ),
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                  ),
                                  label: const Text('Rentang Tanggal'),
                                ),
                                const SizedBox(width: 8),
                                OutlinedButton(
                                  onPressed: _clearDates,
                                  style: OutlinedButton.styleFrom(
                                    side: const BorderSide(color: Colors.black, width: 1),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                  ),
                                  child: const Text('Clear'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),

                            // Chip tanggal awal–akhir (tap: pilih tanggal per chip)
                            Row(
                              children: [
                                Expanded(
                                  child: InkWell(
                                    onTap: () => _selectDate(context, true),
                                    borderRadius: BorderRadius.circular(40),
                                    child: _DatePill(
                                      label: 'Tanggal Awal',
                                      value: _startDate == null ? '—' : fmtChip.format(_startDate!),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: InkWell(
                                    onTap: () => _selectDate(context, false),
                                    borderRadius: BorderRadius.circular(40),
                                    child: _DatePill(
                                      label: 'Tanggal Akhir',
                                      value: _endDate == null ? '—' : fmtChip.format(_endDate!),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),

                            // Preset cepat
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                _PresetChip(text: 'Semua Data', onTap: () => _applyPreset('all')),
                                _PresetChip(text: 'Bulan Ini', onTap: () => _applyPreset('month')),
                                _PresetChip(text: '100 Hari Terakhir', onTap: () => _applyPreset('100')),
                              ],
                            ),
                            const SizedBox(height: 24),
                          ],
                        ),

                        _buildInfoTile('LABA BERSIH',
                            formatCurrency.format(_labaBersih)),
                        _buildInfoTile('BAGIAN KARYAWAN (50% LABA BERSIH)',
                            formatCurrency.format(bagianKaryawan)),
                        _buildInfoTile('BAGIAN DIREKSI (50% LABA BERSIH)',
                            formatCurrency.format(bagianDireksi)),

                        Row(
                          children: [
                            const Text('TOTAL MATO CABANG',
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.6),
                                borderRadius: BorderRadius.circular(40),
                                border: Border.all(color: Colors.black, width: 1),
                              ),
                              child: Text(_totalMato.toString()),
                            ),
                            const Spacer(),
                            IconButton(
                              icon: Icon(Icons.info_outline,
                                  color:
                                  _showInfo ? Colors.black : Colors.grey),
                              onPressed: () =>
                                  setState(() => _showInfo = !_showInfo),
                            )
                          ],
                        ),

                        if (_showInfo)
                          Container(
                            margin: const EdgeInsets.only(top: 8),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.6),
                              borderRadius: BorderRadius.circular(40),
                              border:
                              Border.all(color: Colors.black, width: 1),
                            ),
                            child: const Text.rich(
                              TextSpan(
                                children: [
                                  TextSpan(
                                      text: 'Laba bersih ',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                  TextSpan(
                                      text:
                                      'akan dibagi menjadi dua bagian:\n'),
                                  TextSpan(
                                      text: '- 50% untuk karyawan\n'),
                                  TextSpan(
                                      text: '- 50% untuk direksi\n\n'),
                                  TextSpan(
                                      text:
                                      'Untuk menghitung Income per Mato, '),
                                  TextSpan(
                                    text: 'ambil 50% bagian karyawan ',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold),
                                  ),
                                  TextSpan(
                                    text:
                                    'lalu dibagi dengan total poin mato seluruh pegawai yang telah diinput.\n\n',
                                  ),
                                  TextSpan(text: 'Rumus:\n'),
                                  TextSpan(
                                    text:
                                    'Income per Mato = (50% × Laba Bersih) ÷ Total Mato Cabang\n\n',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold),
                                  ),
                                  TextSpan(text: 'Contoh:\n'),
                                  TextSpan(
                                    text:
                                    'Jika laba bersih = Rp 50.000.000 dan total mato = 10, maka:\n',
                                  ),
                                  TextSpan(
                                    text:
                                    'Income per Mato = (50% × 50.000.000) ÷ 10 = Rp 2.500.000',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        const SizedBox(height: 24),

                        // Income Per Mato Box
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(
                              vertical: 16, horizontal: 24),
                          decoration: BoxDecoration(
                            color: Color(0xFFA0E7C2),
                            borderRadius: BorderRadius.circular(40),
                            border: Border.all(color: Colors.black, width: 1),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('INCOME PER MATO',
                                  style:
                                  TextStyle(fontWeight: FontWeight.bold)),
                              Text(
                                formatCurrency.format(incomePerMato),
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),

                        ElevatedButton(
                          onPressed: _simpanKeSupabase,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.redAccent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(40)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 24, vertical: 14),
                          ),
                          child: const Text(
                            "Simpan Laporan",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        const Spacer(), // ✅ akan dorong ke bawah
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildInfoTile(String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.6),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1), // tambahkan ini
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(value, style: const TextStyle(
              color: Colors.orange, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}
