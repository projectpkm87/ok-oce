import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


class OmzetPage extends StatefulWidget {
  const OmzetPage({super.key});

  @override
  State<OmzetPage> createState() => _OmzetPageState();
}

class _OmzetPageState extends State<OmzetPage> {
  final _formKey = GlobalKey<FormState>();
  DateTime _selectedDate = DateTime.now();
  final TextEditingController _nominalController = TextEditingController();

  List<Map<String, dynamic>> dummyOmzet = [];

  void _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2024, 1),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _submitOmzet() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        dummyOmzet.add({
          "tanggal": DateFormat('yyyy-MM-dd').format(_selectedDate),
          "nominal": int.parse(_nominalController.text),
        });
        _nominalController.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Input Omzet Harian')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: InkWell(
                      onTap: _pickDate,
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: 'Tanggal',
                          border: OutlineInputBorder(),
                        ),
                        child: Text(DateFormat('yyyy-MM-dd').format(_selectedDate)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 3,
                    child: TextFormField(
                      controller: _nominalController,
                      decoration: const InputDecoration(
                        labelText: 'Nominal Omzet',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Wajib diisi';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _submitOmzet,
                    child: const Text('Simpan'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text('Daftar Omzet Tersimpan', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: dummyOmzet.length,
                itemBuilder: (context, index) {
                  final item = dummyOmzet[index];
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.receipt),
                      title: Text("Tanggal: ${item['tanggal']}"),
                      subtitle: Text("Nominal: Rp ${item['nominal']}"),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
