import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// PDF
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class LaporanStok extends StatefulWidget {
  final String idCabang;
  const LaporanStok({super.key, required this.idCabang});

  @override
  State<LaporanStok> createState() => _LaporanStokState();
}

class _LaporanStokState extends State<LaporanStok> {
  final supabase = Supabase.instance.client;

  String? selectedKategori;
  List<String> kategoriList = [];

  // baris laporan hasil agregasi per bahan
  List<Map<String, dynamic>> _rows = [];
  bool _loading = false;

  DateTime? startDate;
  DateTime? endDate;

  // formatter
  final DateFormat _fmtChip = DateFormat('d MMM yyyy', 'id_ID');
  final DateFormat _fmtIso = DateFormat('yyyy-MM-dd');
  final NumberFormat _nf = NumberFormat.decimalPattern('id_ID');

  // --- sinkron scroll header-body seperti Laba Bersih
  final _hHeader = ScrollController();
  final _hBody   = ScrollController();
  final _vBody   = ScrollController();

  // --- header tabel & lebar dasar kolom (akan diskalakan responsif)
  final List<String> _headers = const [
    'Nama', 'Awal', 'Beli', 'Ambil', 'Stok Akhir', 'Total Harga', 'Satuan',
  ];
  final List<double> _baseWidths = const [
    220, 130, 130, 130, 150, 170, 140,
  ];

  @override
  void initState() {
    super.initState();
    _fetchKategori();
    if (selectedKategori != null) _fetchReport();

    // sinkronisasi scroll header <-> body
    _hHeader.addListener(() {
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _hBody.jumpTo(_hHeader.offset);
      }
    });
    _hBody.addListener(() {
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _hHeader.jumpTo(_hBody.offset);
      }
    });
  }

  @override
  void dispose() {
    _hHeader.dispose();
    _hBody.dispose();
    _vBody.dispose();
    super.dispose();
  }

  // ================== HELPERS ==================
  num _num(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  // ================== DATA: kategori (master) ==================
  Future<void> _fetchKategori() async {
    try {
      var q = supabase
          .from('laporan_stok')
          .select('kategori')
          .eq('id_cabang', widget.idCabang);

      // filter rentang tanggal jika terisi
      if (startDate != null) {
        q = q.gte('tanggal', _fmtIso.format(startDate!));
      }
      if (endDate != null) {
        q = q.lte('tanggal', _fmtIso.format(endDate!));
      }

      final rows = await q;
      final list = (rows as List<dynamic>)
          .map<String>((r) => (r['kategori'] ?? '').toString().trim())
          .where((s) => s.isNotEmpty)
          .toSet()
          .toList()
        ..sort();

      // sisipkan opsi ALL
      list.insert(0, 'Semua Kategori');

      if (!mounted) return;
      setState(() {
        kategoriList = list;

        // reset pilihan jika sudah tidak valid
        if (selectedKategori != null && !kategoriList.contains(selectedKategori)) {
          selectedKategori = null;
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat kategori: $e')),
      );
    }
  }

  // ================== DATA: laporan dari InputPBP ==================
  Future<void> _fetchReport() async {
    // butuh kategori & range tanggal untuk memfilter
    if (selectedKategori == null || startDate == null || endDate == null) {
      setState(() => _rows = []);
      return;
    }

    setState(() => _loading = true);

    try {
      // base query
      var q = supabase
          .from('laporan_stok')
      // pakai kolom baru id_bahan + bawa satuan, total_harga, stok_akhir
          .select('id_bahan, nama_bahan, satuan, awal, beli, ambil, stok_akhir, total_harga, tanggal, kategori')
          .eq('id_cabang', widget.idCabang)
          .gte('tanggal', _fmtIso.format(startDate!))
          .lte('tanggal', _fmtIso.format(endDate!));

      // filter kategori kecuali "Semua Kategori"
      if (selectedKategori != 'Semua Kategori') {
        q = q.eq('kategori', selectedKategori);
      }

      final data = await q.order('nama_bahan');
      final list = List<Map<String, dynamic>>.from(data);

      // agregasi per id_bahan di sisi klien
      final Map<String, Map<String, dynamic>> agg = {};
      for (final r in list) {
        final id   = (r['id_bahan'] ?? '').toString();
        final nama = (r['nama_bahan'] ?? '').toString();
        final sat  = (r['satuan'] ?? '').toString();

        final a  = _num(r['awal']);
        final b  = _num(r['beli']);
        final c  = _num(r['ambil']);
        final th = _num(r['total_harga']);

        final bucket = agg.putIfAbsent(id, () => {
          'id': id,
          'nama_bahan': nama,
          'satuan': sat,
          'awal': 0,
          'beli': 0,
          'ambil': 0,
          'total_harga': 0,
        });

        bucket['awal']        = (bucket['awal'] as num) + a;
        bucket['beli']        = (bucket['beli'] as num) + b;
        bucket['ambil']       = (bucket['ambil'] as num) + c;
        bucket['total_harga'] = (bucket['total_harga'] as num) + th;

        // kalau satuan kosong di bucket, isi dari row ini
        if ((bucket['satuan'] as String).isEmpty && sat.isNotEmpty) {
          bucket['satuan'] = sat;
        }
      }

      final rows = agg.values.map((m) {
        final awal  = m['awal'] as num;
        final beli  = m['beli'] as num;
        final ambil = m['ambil'] as num;
        m['akhir']  = awal + beli - ambil; // stok akhir agregat sederhana
        return m;
      }).toList()
        ..sort((a, b) => (a['nama_bahan'] as String).compareTo(b['nama_bahan'] as String));

      if (!mounted) return;
      setState(() {
        _rows = rows;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat laporan: $e')),
      );
    }
  }

  // ========== Date range helpers ==========
  void _clearRange() {
    setState(() {
      startDate = null;
      endDate = null;
      _rows = [];
    });
  }

  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: startDate ?? DateTime(now.year, now.month, 1),
      end: endDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(useMaterial3: false),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        startDate = picked.start;
        endDate = picked.end;
      });
      _fetchReport();
      if (selectedKategori != null) _fetchReport();
    }
  }

  void _applyPresetRange(String code) {
    final now = DateTime.now();
    if (code == 'all') {
      setState(() {
        startDate = DateTime(2020, 1, 1);
        endDate = now;
      });
    } else if (code == 'month') {
      setState(() {
        startDate = DateTime(now.year, now.month, 1);
        endDate = DateTime(now.year, now.month + 1, 0);
      });
    } else if (code == '7') {
      setState(() {
        startDate = now.subtract(const Duration(days: 6));
        endDate = now;
      });
    } else if (code == '30') {
      setState(() {
        startDate = now.subtract(const Duration(days: 29));
        endDate = now;
      });
    }
    _fetchReport();
    if (selectedKategori != null) _fetchReport();
  }

  // ========== Export PDF (pakai _rows hasil agregasi) ==========
  Future<void> _exportPdf() async {
    if (selectedKategori == null || selectedKategori!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pilih kategori terlebih dahulu")),
      );
      return;
    }
    if (startDate == null || endDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pilih rentang tanggal terlebih dahulu")),
      );
      return;
    }
    if (_rows.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Tidak ada data untuk diexport")),
      );
      return;
    }

    final doc = pw.Document();
    final headers = <String>[
      'Nama',
      'Awal',
      'Beli',
      'Ambil',
      'Stok Akhir',
      'Total Harga',
      'Satuan',
    ];

    final data = <List<String>>[
      for (final r in _rows)
        [
          r['nama_bahan'].toString(),
          _nf.format(r['awal']),
          _nf.format(r['beli']),
          _nf.format(r['ambil']),
          _nf.format(r['akhir']),
          '-', // placeholder
          '-', // placeholder
        ],
    ];

    // ringkasan total
    num tAwal = 0, tBeli = 0, tAmbil = 0, tAkhir = 0;
    for (final r in _rows) {
      tAwal += _num(r['awal']);
      tBeli += _num(r['beli']);
      tAmbil += _num(r['ambil']);
      tAkhir += _num(r['akhir']);
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(24),
        build: (context) => [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text(
                'Laporan ALPB (Analisa Pemakaian Bahan Pokok)',
                style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
              ),
              pw.Text(
                'Cabang: ${widget.idCabang}',
                style: const pw.TextStyle(fontSize: 12),
              ),
            ],
          ),
          pw.SizedBox(height: 6),
          pw.Text('Kategori: ${selectedKategori ?? "-"}',
              style: const pw.TextStyle(fontSize: 12)),
          pw.Text(
            'Periode: ${_fmtChip.format(startDate!)} s/d ${_fmtChip.format(endDate!)}',
            style: const pw.TextStyle(fontSize: 12),
          ),
          pw.SizedBox(height: 12),

          pw.TableHelper.fromTextArray(
            headers: headers,
            data: data,
            headerStyle: pw.TextStyle(
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.white,
            ),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.blueGrey800),
            cellAlignments: {
              0: pw.Alignment.centerLeft,
              1: pw.Alignment.centerRight,
              2: pw.Alignment.centerRight,
              3: pw.Alignment.centerRight,
              4: pw.Alignment.centerRight,
              5: pw.Alignment.centerRight,
              6: pw.Alignment.center,
            },
            cellStyle: const pw.TextStyle(fontSize: 10),
            headerHeight: 24,
            cellHeight: 22,
            border: null,
            oddRowDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF5F5F5)),
          ),

          pw.SizedBox(height: 12),
          pw.Align(
            alignment: pw.Alignment.centerRight,
            child: pw.Container(
              padding: const pw.EdgeInsets.all(8),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey),
                borderRadius: pw.BorderRadius.circular(6),
              ),
              child: pw.Row(
                mainAxisSize: pw.MainAxisSize.min,
                children: [
                  pw.Text('Total  ', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(width: 10),
                  pw.Text('Awal: ${_nf.format(tAwal)}   '
                      'Beli: ${_nf.format(tBeli)}   '
                      'Ambil: ${_nf.format(tAmbil)}   '
                      'Akhir: ${_nf.format(tAkhir)}'),
                ],
              ),
            ),
          ),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => doc.save(),
      name: 'Laporan_ALPB_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.pdf',
    );
  }

  // ================== UI (filter tanggal bar) ==================
  Widget _dateRangeBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('Tanggal (Rentang)',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _openRangePicker,
              icon: const Icon(Icons.date_range, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFE4E9),
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                  side: const BorderSide(color: Colors.black, width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
              label: const Text('Rentang Tanggal'),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: _clearRange,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.black, width: 1),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              child: const Text('Clear'),
            ),
          ],
        ),
        const SizedBox(height: 10),

        Row(
          children: [
            Expanded(
              child: _DatePill(
                label: 'Tanggal Awal',
                value: startDate == null ? '—' : _fmtChip.format(startDate!),
                onTap: _openRangePicker,
              ),
            ),
            const SizedBox(width: 8),
            const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            Expanded(
              child: _DatePill(
                label: 'Tanggal Akhir',
                value: endDate == null ? '—' : _fmtChip.format(endDate!),
                onTap: _openRangePicker,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),

        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _PresetChip(text: 'Semua Data', onTap: () => _applyPresetRange('all')),
            _PresetChip(text: 'Bulan Ini', onTap: () => _applyPresetRange('month')),
            _PresetChip(text: '7 Hari', onTap: () => _applyPresetRange('7')),
            _PresetChip(text: '30 Hari', onTap: () => _applyPresetRange('30')),
          ],
        ),
      ],
    );
  }

  // ================== UI: header & row kapsul (gaya Laba Bersih) ==================
  Widget _buildHeader(List<double> widths) {
    const double sideInset = 20; // margin+padding seperti di LB
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: sideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: { for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(
            children: List.generate(_headers.length, (i) {
              return Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  _headers[i],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholderStock(List<double> widths) {
    return _capsuleRow(
      child: Table(
        columnWidths: { for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(children: List.generate(widths.length, (i) => _cellText('–'))),
        ],
      ),
    );
  }

  Widget _dataRowStock({
    required List<double> widths,
    required Map<String, dynamic> r,
    required bool isFirst,
  }) {
    return _capsuleRow(
      top: isFirst ? 6 : 12,
      child: Table(
        columnWidths: { for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(
            children: [
              _cellText(r['nama_bahan'].toString()),
              _cellText(_nf.format(_num(r['awal']))),
              _cellText(_nf.format(_num(r['beli']))),
              _cellText(_nf.format(_num(r['ambil']))),
              _cellText(_nf.format(_num(r['akhir']))),
              _cellText(_nf.format(_num(r['total_harga']))),     // <<< sebelumnya '-'
              _cellText((r['satuan'] ?? '-').toString()),        // <<< sebelumnya '-'
            ],
          ),
        ],
      ),
    );
  }

  Widget _capsuleRow({required Widget child, double top = 12}) {
    return Container(
      margin: EdgeInsets.only(top: top, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: child,
    );
  }

  Widget _cellText(String text) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Laporan Stok",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
        centerTitle: false,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFC5CC), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 50),

            // Rentang Tanggal
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
              child: _dateRangeBar(),
            ),

            const SizedBox(height: 10),

            // Kategori
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30)),
                ),
                hint: const Text("Pilih Kategori"),
                value: selectedKategori,
                items: kategoriList
                    .map((kategori) => DropdownMenuItem(
                  value: kategori,
                  child: Text(kategori),
                ))
                    .toList(),
                onChanged: (value) {
                  setState(() => selectedKategori = value);
                  _fetchReport();
                },
              ),
            ),

            // ====== TABEL (UI kapsul + header sinkron) ======
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final minTotal = _baseWidths.reduce((a, b) => a + b);
                  final available = c.maxWidth - 24; // padding dalam card
                  final totalW = (available >= minTotal) ? available : minTotal.toDouble();
                  final scale  = totalW / minTotal;
                  final widths = _baseWidths.map((w) => w * scale).toList();
                  final tableWidth = widths.reduce((a, b) => a + b);

                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 14,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                    child: Column(
                      children: [
                        // HEADER (sinkron horizontal)
                        Scrollbar(
                          controller: _hHeader,
                          thumbVisibility: true,
                          child: SingleChildScrollView(
                            controller: _hHeader,
                            scrollDirection: Axis.horizontal,
                            child: SizedBox(
                              width: tableWidth,
                              child: _buildHeader(widths),
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),

                        // BODY (VS + HS) – tiap baris = card kapsul
                        Expanded(
                          child: Scrollbar(
                            controller: _vBody,
                            thumbVisibility: true,
                            child: SingleChildScrollView(
                              controller: _vBody,
                              child: Scrollbar(
                                controller: _hBody,
                                notificationPredicate: (n) => n.depth == 1,
                                thumbVisibility: true,
                                child: SingleChildScrollView(
                                  controller: _hBody,
                                  scrollDirection: Axis.horizontal,
                                  child: SizedBox(
                                    width: tableWidth,
                                    child: _loading
                                        ? const Padding(
                                      padding: EdgeInsets.all(24.0),
                                      child: Center(
                                          child: CircularProgressIndicator()),
                                    )
                                        : (_rows.isEmpty
                                        ? _buildPlaceholderStock(widths)
                                        : Column(
                                      children: List.generate(
                                        _rows.length,
                                            (i) => _dataRowStock(
                                          widths: widths,
                                          r: _rows[i],
                                          isFirst: i == 0,
                                        ),
                                      ),
                                    )),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),

            // Export PDF
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton.icon(
                onPressed: _exportPdf,
                icon: const Icon(Icons.picture_as_pdf),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)),
                ),
                label: const Text(
                  "Export PDF",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ===== Reusable kecil: pill & preset chip =====
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback? onTap;
  const _DatePill({required this.label, required this.value, this.onTap});

  @override
  Widget build(BuildContext context) {
    final pill = Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );

    return MouseRegion(
      cursor: onTap == null ? SystemMouseCursors.basic : SystemMouseCursors.click,
      child: InkWell(
        borderRadius: BorderRadius.circular(40),
        onTap: onTap,
        child: pill,
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}
