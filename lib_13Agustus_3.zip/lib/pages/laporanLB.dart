import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LaporanLBPage extends StatefulWidget {
  final String idCabang;
  const LaporanLBPage({super.key, required this.idCabang});

  @override
  State<LaporanLBPage> createState() => _LaporanLBPageState();
}

class _LaporanLBPageState extends State<LaporanLBPage> {
  final _supabase = Supabase.instance.client;

  DateTime? _startDate;
  DateTime? _endDate;

  List<Map<String, dynamic>> _rows = [];
  bool _loading = false;

  final _fmtDate = DateFormat('d MMM yyyy', 'id_ID');
  final _fmtCur = NumberFormat.currency(
      locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  // scroll sync
  final _hHeader = ScrollController();
  final _hBody = ScrollController();
  final _vBody = ScrollController();

  RealtimeChannel? _channel;

  // ===== 8 kolom (urutan sesuai permintaan) =====
  final List<String> _headers = const [
    'Tanggal',
    'Pemasukan',
    'HPP',
    'Laba Kotor',
    'Beban Usaha',
    'Sewa & Penyusutan',
    'Servis Kantor',
    'Laba Bersih',
  ];

  // lebar dasar tiap kolom — nanti diskalakan agar responsif
  final List<double> _baseWidths = const [
    160, // Tanggal
    180, // Pemasukan
    160, // HPP
    180, // Laba Kotor
    180, // Beban Usaha
    200, // Sewa & Penyusutan
    180, // Servis Kantor
    180, // Laba Bersih
  ];

  @override
  void initState() {
    super.initState();

    final now = DateTime.now();
    _startDate = DateTime(now.year, now.month, 1);
    _endDate = DateTime(now.year, now.month + 1, 0);

    // sinkron horizontal
    _hHeader.addListener(() {
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _hBody.jumpTo(_hHeader.offset);
      }
    });
    _hBody.addListener(() {
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _hHeader.jumpTo(_hBody.offset);
      }
    });

    _fetchData();
    _subscribeRealtime();
  }

  @override
  void dispose() {
    _hHeader.dispose();
    _hBody.dispose();
    _vBody.dispose();
    if (_channel != null) _supabase.removeChannel(_channel!);
    super.dispose();
  }

  // ===== Realtime (API lama v1.x) =====
  void _subscribeRealtime() {
    final channel = _supabase.channel('rt-laba-bersih-${widget.idCabang}');
    for (final ev in ['INSERT', 'UPDATE', 'DELETE']) {
      channel.on(
        RealtimeListenTypes.postgresChanges,
        ChannelFilter(
          event: ev,
          schema: 'public',
          table: 'laba_bersih',
          filter: 'id_cabang=eq.${widget.idCabang}',
        ),
            (payload, [ref]) => _fetchData(),
      );
    }
    channel.subscribe();
    _channel = channel;
  }

  num _num(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    if (v is String) return num.tryParse(v) ?? 0;
    return 0;
  }

  Future<void> _selectDate(BuildContext context, bool isStart) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          useMaterial3: true,
          datePickerTheme: const DatePickerThemeData(
            backgroundColor: Colors.white,       // kolom kanan
            headerBackgroundColor: Colors.white, // kolom kiri
            headerForegroundColor: Colors.black87,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(16)),
            ),
          ),
          colorScheme: Theme.of(ctx).colorScheme.copyWith(
            surface: Colors.white,
            onSurface: Colors.black87,
            // boleh ganti aksen OK/selected:
            primary: Colors.green,
            onPrimary: Colors.white,
          ),
        ),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
        } else {
          _endDate = picked;
        }
      });
      if (_startDate != null && _endDate != null) {
        await _fetchData();
      }
    }
  }

  Future<void> _fetchData() async {
    setState(() => _loading = true);
    try {
      final qb = _supabase
          .from('laba_bersih')
          .select(
          'tanggal, pemasukan, beban_pokok_penjualan, laba_kotor, beban_usaha, sewa_penyusutan, servis_kantor, total_laba_bersih')
          .eq('id_cabang', widget.idCabang);

      if (_startDate != null) {
        qb.gte('tanggal', DateFormat('yyyy-MM-dd').format(_startDate!));
      }
      if (_endDate != null) {
        qb.lte('tanggal', DateFormat('yyyy-MM-dd').format(_endDate!));
      }

      final data = await qb.order('tanggal');
      setState(() {
        _rows = List<Map<String, dynamic>>.from(data);
      });

      if (_vBody.hasClients) _vBody.jumpTo(0);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat data: $e')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // === Date picker — aman untuk klik kiri/kanan & ukuran apa pun ===
  Future<void> _pickDate({required bool isStart}) async {
    final now = DateTime.now();
    final init = isStart
        ? (_startDate ?? now)
        : (_endDate ?? _startDate ?? now);

    final picked = await showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 1, 12, 31),
      builder: (ctx, child) =>
          Theme(
            // pastikan ada Material theme agar tidak error
            data: Theme.of(ctx).copyWith(useMaterial3: false),
            child: child!,
          ),
    );
    if (picked == null) return;

    setState(() {
      if (isStart) {
        _startDate = picked;
        if (_endDate != null && _endDate!.isBefore(_startDate!)) {
          _endDate = _startDate;
        }
      } else {
        _endDate = picked;
        if (_startDate != null && _startDate!.isAfter(_endDate!)) {
          _startDate = _endDate;
        }
      }
    });

    _fetchData();
  }

  void _resetToCurrentMonth() {
    final now = DateTime.now();
    setState(() {
      _startDate = DateTime(now.year, now.month, 1);
      _endDate = DateTime(now.year, now.month + 1, 0);
    });
    _fetchData();
  }

  @override
  Widget build(BuildContext context) {
    final topSafe = MediaQuery
        .of(context)
        .padding
        .top;

    return Scaffold(
      extendBodyBehindAppBar: true, // <— penting
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        // hindari bayangan saat scroll (Material 3)
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.of(context).maybePop(),
          splashRadius: 22,
        ),
        title: const Text(
          'Laporan Laba Bersih',
          style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFC1CC), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          // jangan pakai SafeArea top karena kita sudah atur manual
          top: false,
          minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: topSafe + kToolbarHeight + 8),
              // spacer agar konten mulai di bawah AppBar
              _filterBar(),
              // bar tanggal
              const SizedBox(height: 10),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, c) {
                    // hitung lebar tabel responsif
                    final minTotal = _baseWidths.reduce((a, b) => a + b);
                    final available = c.maxWidth - 24; // padding dalam card
                    final totalW = max(available, minTotal.toDouble());
                    final scale = totalW / minTotal;
                    final widths = _baseWidths.map((w) => w * scale).toList();

                    final tableWidth = widths.reduce((a, b) => a + b);

                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.35),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 14,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                      child: Column(
                        children: [
                          // header (HS)
                          Scrollbar(
                            controller: _hHeader,
                            thumbVisibility: true,
                            child: SingleChildScrollView(
                              controller: _hHeader,
                              scrollDirection: Axis.horizontal,
                              child: SizedBox(
                                width: tableWidth,
                                child: _buildHeader(widths),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          // body (VS + HS)
                          Expanded(
                            child: Scrollbar(
                              controller: _vBody,
                              thumbVisibility: true,
                              child: SingleChildScrollView(
                                controller: _vBody,
                                child: Scrollbar(
                                  controller: _hBody,
                                  notificationPredicate: (n) => n.depth == 1,
                                  thumbVisibility: true,
                                  child: SingleChildScrollView(
                                    controller: _hBody,
                                    scrollDirection: Axis.horizontal,
                                    child: SizedBox(
                                      width: tableWidth,
                                      child: _loading
                                          ? const Padding(
                                        padding: EdgeInsets.all(24.0),
                                        child: Center(
                                            child: CircularProgressIndicator()),
                                      )
                                          : (_rows.isEmpty
                                          ? _buildPlaceholder(widths)
                                          : Column(
                                        children: List.generate(
                                          _rows.length,
                                              (i) {
                                            final r = _rows[i];
                                            final tanggal =
                                            DateTime.parse(
                                                r['tanggal'].toString());
                                            final pemasukan = _num(
                                                r['pemasukan']);
                                            final hpp = _num(
                                                r['beban_pokok_penjualan']);
                                            final labaKotor = _num(
                                                r['laba_kotor']);
                                            final bebanUsaha = _num(
                                                r['beban_usaha']);
                                            final sewaPeny = _num(
                                                r['sewa_penyusutan']);
                                            final servisKtr = _num(
                                                r['servis_kantor']);
                                            final labaBersih = _num(
                                                r['total_laba_bersih']);

                                            final cells = <String>[
                                              _fmtDate.format(tanggal),
                                              _fmtCur.format(pemasukan),
                                              _fmtCur.format(hpp),
                                              _fmtCur.format(labaKotor),
                                              _fmtCur.format(bebanUsaha),
                                              _fmtCur.format(sewaPeny),
                                              _fmtCur.format(servisKtr),
                                              _fmtCur.format(labaBersih),
                                            ];

                                            return _dataRow(
                                              widths: widths,
                                              cells: cells,
                                              isFirst: i == 0,
                                            );
                                          },
                                        ),
                                      )),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              // tidak ada garis putih bawah lagi
            ],
          ),
        ),
      ),
    );
  }

  void _clearDates() {
    setState(() {
      _startDate = null;
      _endDate = null;
      _rows = [];
    });
  }

  Future<void> _openRangePicker() async {
    final now = DateTime.now();
    final initial = DateTimeRange(
      start: _startDate ?? DateTime(now.year, now.month, 1),
      end: _endDate ?? now,
    );

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: initial,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(useMaterial3: false),
        child: child!,
      ),
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate   = picked.end;
      });
      _fetchData();
    }
  }

  Future<void> _applyPreset(String code) async {
    final now = DateTime.now();

    if (code == 'all') {
      setState(() {
        _startDate = DateTime(2020, 1, 1);
        _endDate = now;
      });
    } else if (code == 'month') {
      setState(() {
        _startDate = DateTime(now.year, now.month, 1);
        _endDate = DateTime(now.year, now.month + 1, 0);
      });
    } else if (code == '100') {
      setState(() {
        _startDate = now.subtract(const Duration(days: 99));
        _endDate = now;
      });
    }

    await _fetchData();
  }

  // ===== UI helpers =====

  Widget _filterBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Bar atas: Rentang & Clear
        Row(
          children: [
            const Text(
              'Tanggal (Rentang)',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _openRangePicker,
              icon: const Icon(Icons.date_range, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFE4E9),
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                  side: const BorderSide(color: Colors.black, width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
              label: const Text('Rentang Tanggal'),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: _clearDates,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.black, width: 1),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              child: const Text('Clear'),
            ),
          ],
        ),
        const SizedBox(height: 10),

        // Chip tanggal awal–akhir (tap: pilih per chip)
        Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: () => _selectDate(context, true),
                borderRadius: BorderRadius.circular(40),
                child: _DatePill(
                  label: 'Tanggal Awal',
                  value: _startDate == null ? '—' : _fmtDate.format(_startDate!),
                ),
              ),
            ),
            const SizedBox(width: 8),
            const Text('-', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            Expanded(
              child: InkWell(
                onTap: () => _selectDate(context, false),
                borderRadius: BorderRadius.circular(40),
                child: _DatePill(
                  label: 'Tanggal Akhir',
                  value: _endDate == null ? '—' : _fmtDate.format(_endDate!),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),

        // Preset cepat
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _PresetChip(text: 'Semua Data', onTap: () => _applyPreset('all')),
            _PresetChip(text: 'Bulan Ini', onTap: () => _applyPreset('month')),
            _PresetChip(text: '100 Hari Terakhir', onTap: () => _applyPreset('100')),
          ],
        ),
      ],
    );
  }

  Widget _dateChip({required String label, required VoidCallback onTap}) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.black.withOpacity(0.10)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.calendar_today_rounded, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(List<double> widths) {
    const double kSideInset = 20; // = margin(6) + padding(14) dari _capsuleRow
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: kSideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: {for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])},
        children: [
          TableRow(
            children: List.generate(_headers.length, (i) {
              return Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 0),
                child: Text(
                  _headers[i],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder(List<double> widths) {
    return _capsuleRow(
      child: Table(
        columnWidths: {
          for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])
        },
        children: [
          TableRow(
            children: List.generate(widths.length, (i) => _cellText('–')),
          ),
        ],
      ),
    );
  }

  Widget _dataRow({
    required List<double> widths,
    required List<String> cells,
    required bool isFirst,
  }) {
    return _capsuleRow(
      top: isFirst ? 6 : 12,
      child: Table(
        columnWidths: {
          for (int i = 0; i < widths.length; i++) i: FixedColumnWidth(widths[i])
        },
        children: [
          TableRow(children: cells.map(_cellText).toList()),
        ],
      ),
    );
  }

  Widget _capsuleRow({required Widget child, double top = 12}) {
    return Container(
      margin: EdgeInsets.only(top: top, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08),
              blurRadius: 10,
              offset: const Offset(0, 4)),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: child,
    );
  }

  Widget _cellText(String text) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 0), // was 4
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
      ),
    );
  }
}

class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}

