import 'dart:async';
import 'package:flutter/material.dart';
import 'package:laporan_keuangan1/pages/login_page.dart'; // ganti dengan halaman tujuan kamu

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();

    // Timer 3 detik, lalu pindah ke halaman login
    Timer(const Duration(seconds: 6, microseconds: 500), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const LoginPage(), // ganti sesuai kebutuhan
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFFF9F9), // Pink muda
              Color(0xFFFFFFFF), // Putih
            ],
          ),
        ),
        child: Center(
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Radial gradient soft blur behind the GIF
              Container(
                width: 760,
                height: 760,
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 0.65,
                    colors: [
                      Color(0xFFFFF9F9), // warna dalam, mirip bg
                      Color(0x00FFFFFF), // makin transparan
                    ],
                  ),
                ),
              ),
              // Logo GIF
              Image.asset(
                'assets/logo1.gif',
                width: 720,
                height: 720,
                fit: BoxFit.contain,
              ),
            ],
          ),
        ),
      ),
    );
  }
}