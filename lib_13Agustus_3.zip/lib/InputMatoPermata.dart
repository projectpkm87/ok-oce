import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InputMatoPermata extends StatefulWidget {
  final String cabangId; // dari login session

  const InputMatoPermata({Key? key, required this.cabangId}) : super(key: key);

  @override
  State<InputMatoPermata> createState() => _InputMatoPermataState();
}

class _InputMatoPermataState extends State<InputMatoPermata> {
  final List<String> _jabatanList = [
    'Manager',
    'Supervisor',
    'Kasir',
    'Koki',
    'Pelayan',
    'Kebersihan',
  ];

  final Map<String, TextEditingController> _controllers = {};
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    for (var jab in _jabatanList) {
      _controllers[jab] = TextEditingController();
    }
  }

  @override
  void dispose() {
    for (var controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _submitData() async {
    setState(() => _isLoading = true);

    final supabase = Supabase.instance.client;
    final cabangId = widget.cabangId;

    try {
      for (var jab in _jabatanList) {
        final nilai = int.tryParse(_controllers[jab]?.text ?? '') ?? 0;
        final finalNilai = nilai > 10 ? 10 : nilai;

        await supabase.from('ketentuan_mato').insert({
          'cabang_id': cabangId,
          'jabatan': jab,
          'maksimal_mato': finalNilai,
        });
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data berhasil disimpan')),
      );

      Navigator.pop(context); // kembali ke dashboard_cabang
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menyimpan data: $e')),
      );
    }

    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ketentuan MATO per Jabatan'),
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: ListView.separated(
                itemCount: _jabatanList.length,
                separatorBuilder: (_, __) => const SizedBox(height: 16),
                itemBuilder: (context, index) {
                  final jabatan = _jabatanList[index];
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        jabatan,
                        style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _controllers[jabatan],
                        keyboardType: TextInputType.number,
                        maxLength: 2,
                        decoration: InputDecoration(
                          hintText: 'Max 10',
                          counterText: '',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          final val = int.tryParse(value);
                          if (val != null && val > 10) {
                            _controllers[jabatan]!.text = '10';
                            _controllers[jabatan]!.selection = TextSelection.fromPosition(
                              const TextPosition(offset: 2),
                            );
                          }
                        },
                      ),
                    ],
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              onPressed: _isLoading ? null : _submitData,
              icon: const Icon(Icons.save),
              label: Text(_isLoading ? 'Menyimpan...' : 'Simpan Data'),
            )
          ],
        ),
      ),
    );
  }
}
