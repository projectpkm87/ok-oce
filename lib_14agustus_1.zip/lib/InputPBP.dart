import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InputPBP extends StatefulWidget {
  final String idCabang;
  const InputPBP({super.key, required this.idCabang});

  @override
  State<InputPBP> createState() => _InputPBPState();
}

class _InputPBPState extends State<InputPBP> {
  final supabase = Supabase.instance.client;

  String? selectedKategori;
  List<String> kategoriList = [];
  List<Map<String, dynamic>> bahanList = [];

  // key: idBahan (String)
  final Map<String, TextEditingController> awalCtrl = {};
  final Map<String, TextEditingController> beliCtrl = {};
  final Map<String, TextEditingController> ambilCtrl = {};
  final Map<String, num> stokAkhir = {};

  DateTime? selectedDate;

  // formatter
  final DateFormat _fmtChip = DateFormat('d MMM yyyy', 'id_ID');

  // --- sinkron scroll header-body (seperti LaporanStok)
  final _hHeader = ScrollController();
  final _hBody   = ScrollController();
  final _vBody   = ScrollController();

  // --- header & lebar dasar kolom (akan diskalakan responsif)
  final List<String> _headers = const [
    'Nama', 'Awal', 'Beli', 'Ambil', 'Stok Akhir', 'Total Harga', 'Satuan',
  ];
  final List<double> _baseWidths = const [
    220, 130, 130, 130, 150, 170, 140,
  ];

  @override
  void initState() {
    super.initState();
    _fetchKategori();

    // sinkron horizontal
    _hHeader.addListener(() {
      if (_hBody.hasClients && _hBody.offset != _hHeader.offset) {
        _hBody.jumpTo(_hHeader.offset);
      }
    });
    _hBody.addListener(() {
      if (_hHeader.hasClients && _hHeader.offset != _hBody.offset) {
        _hHeader.jumpTo(_hBody.offset);
      }
    });
  }

  @override
  void dispose() {
    for (final c in awalCtrl.values) c.dispose();
    for (final c in beliCtrl.values) c.dispose();
    for (final c in ambilCtrl.values) c.dispose();
    _hHeader.dispose();
    _hBody.dispose();
    _vBody.dispose();
    super.dispose();
  }

  // ================== DATA ==================
  Future<void> _fetchKategori() async {
    try {
      // base query
      var q = supabase
          .from('bahan_pokok')
          .select('jenis')
          .eq('id_cabang', widget.idCabang);

      // filter tanggal bila dipilih (kolom tanggal = DATE)
      if (selectedDate != null) {
        final t = DateFormat('yyyy-MM-dd').format(selectedDate!);
        q = q.eq('tanggal', t);
      }

      final rows = await q;

      // pastikan hasilnya bertipe String agar .where() mengembalikan bool
      final List<String> distinctKategori = (rows as List<dynamic>)
          .map<String>((r) => (r['jenis'] ?? '').toString().trim())
          .where((String s) => s.isNotEmpty)
          .toSet()
          .toList()
        ..sort();

      // tambah opsi ALL
      distinctKategori.insert(0, 'Semua Kategori');

      if (!mounted) return;
      setState(() {
        kategoriList = distinctKategori;

        // reset pilihan jika tak valid setelah filter tanggal
        if (selectedKategori != null && !kategoriList.contains(selectedKategori)) {
          selectedKategori = null;
          bahanList = [];
        }
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat kategori: $e')),
      );
    }
  }

  // Ambil peta {id_bahan -> stok_akhir} untuk H-1.
  // Kalau tidak ada data H-1, fungsi ini mengembalikan {}.
  Future<Map<String, num>> _fetchAwalMapFromPrevDay() async {
    if (selectedDate == null) return {};
    final prev = selectedDate!.subtract(const Duration(days: 1));
    final tPrev = DateFormat('yyyy-MM-dd').format(prev);

    final rows = await supabase
        .from('laporan_stok')
        .select('id_bahan, stok_akhir')   // ← pakai id_bahan
        .eq('id_cabang', widget.idCabang)
        .eq('tanggal', tPrev);

    final map = <String, num>{};
    for (final r in rows) {
      final k = (r['id_bahan'] ?? '').toString();
      final num akhir = (r['stok_akhir'] is num)
          ? r['stok_akhir'] as num
          : num.tryParse((r['stok_akhir'] ?? '0').toString()) ?? 0;
      if (k.isNotEmpty) map[k] = akhir;
    }
    return map;
  }

  Future<void> _fetchBahan(String? kategori) async {
    try {
      // Ambil data dari tabel bahan_pokok untuk tanggal & kategori terpilih
      var q = supabase
          .from('bahan_pokok')
          .select('id, id_bahan, nama_bahan, jenis, jumlah, satuan, harga')
          .eq('id_cabang', widget.idCabang) as PostgrestFilterBuilder;

      if (selectedDate != null) {
        final t = DateFormat('yyyy-MM-dd').format(selectedDate!);
        q = q.eq('tanggal', t);
      }
      if (kategori != null && kategori != 'Semua Kategori') {
        q = q.eq('jenis', kategori);
      }

      final response = await q.order('nama_bahan');
      bahanList = List<Map<String, dynamic>>.from(response);

      // Ambil stok_akhir H-1 sebagai stok awal hari ini
      final prevMap = await _fetchAwalMapFromPrevDay();

      // reset controllers
      for (final c in awalCtrl.values) c.dispose();
      for (final c in beliCtrl.values) c.dispose();
      for (final c in ambilCtrl.values) c.dispose();
      awalCtrl.clear(); beliCtrl.clear(); ambilCtrl.clear(); stokAkhir.clear();

      for (final b in bahanList) {
        final id = b['id'].toString();
        final kodeIdBahan = (b['id_bahan'] ?? '').toString(); // untuk relasi & cari awal H-1

        final num jumlah = (b['jumlah'] is num)
            ? (b['jumlah'] as num)
            : num.tryParse((b['jumlah'] ?? '0').toString()) ?? 0;

        // --- LOGIKA BARU ---
        // Jika ada data H-1: Awal = stok_akhir(H-1)
        // Jika tidak ada (hari pertama): Awal = 0
        final num awal = prevMap[kodeIdBahan] ?? 0;

        awalCtrl[id]  = TextEditingController(text: awal.toString());
        beliCtrl[id]  = TextEditingController(text: jumlah.toString());
        ambilCtrl[id] = TextEditingController(text: '0');

        // Langsung akumulasi agar Stok Akhir & Total Harga muncul tanpa interaksi
        stokAkhir[id] = awal + jumlah; // (ambil default 0)
      }

      if (mounted) setState(() {});
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat bahan: $e')),
      );
    }
  }

  void _hitungStok(String idBahan) {
    final awal  = num.tryParse(awalCtrl[idBahan]?.text ?? '0') ?? 0;
    final beli  = num.tryParse(beliCtrl[idBahan]?.text ?? '0') ?? 0;
    final ambil = num.tryParse(ambilCtrl[idBahan]?.text ?? '0') ?? 0;
    stokAkhir[idBahan] = awal + beli - ambil;
    setState(() {});
    // catatan: logika tetap sama; hanya UI yang berubah
  }

  Future<void> _simpanData() async {
    if (selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pilih tanggal terlebih dahulu")),
      );
      return;
    }
    if (selectedKategori == null || selectedKategori!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Pilih kategori terlebih dahulu")),
      );
      return;
    }
    if (bahanList.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Tidak ada data bahan untuk disimpan")),
      );
      return;
    }

    try {
      final tanggal = DateFormat('yyyy-MM-dd').format(selectedDate!);

      final rows = <Map<String, dynamic>>[
        for (final b in bahanList)
              () {
            final idKey = b['id'].toString();

            final num awal  = num.tryParse(awalCtrl[idKey]?.text ?? '0') ?? 0;
            final num beli  = num.tryParse(beliCtrl[idKey]?.text ?? '0') ?? 0;   // ← pakai 'beli', bukan 'jumlah'
            final num ambil = num.tryParse(ambilCtrl[idKey]?.text ?? '0') ?? 0;
            final num akhir = awal + beli - ambil;

            final num harga = (b['harga'] is num)
                ? (b['harga'] as num)
                : num.tryParse((b['harga'] ?? '0').toString()) ?? 0;
            final num total = akhir * harga;

            return {
              'id_cabang': widget.idCabang,
              'tanggal': tanggal,
              'id_bahan': b['id_bahan'], // <- kalau skema report sudah pakai id_bahan
              'kategori': (selectedKategori == 'Semua Kategori')
                  ? (b['jenis'] ?? '')
                  : selectedKategori,
              'nama_bahan': b['nama_bahan'],
              'satuan': b['satuan'] ?? '',
              'awal': awal,
              'beli': beli,              // ← simpan ke kolom 'beli'
              'ambil': ambil,
              'stok_akhir': akhir,
              'total_harga': total,
            };
          }(),
      ];

      await supabase
          .from('laporan_stok')
          .upsert(rows, onConflict: 'id_cabang,tanggal,id_bahan'); // pastikan onConflict sesuai skema

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Data stok berhasil disimpan")),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menyimpan: $e')),
      );
    }
  }

  // ================== DATE UI (single date) ==================
  void _clearDate() {
    setState(() => selectedDate = null);
    _fetchKategori(); // refresh daftar kategori tanpa filter tanggal
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(DateTime.now().year + 1, 12, 31),
      builder: (ctx, child) =>
          Theme(data: Theme.of(ctx).copyWith(useMaterial3: false), child: child!),
    );
    if (picked != null) {
      setState(() => selectedDate = picked);
      _fetchKategori(); // refresh kategori sesuai tanggal baru
    }
    if (selectedKategori != null) {
      _fetchBahan(selectedKategori);
    }
  }

  void _applyPreset(String code) {
    final now = DateTime.now();
    DateTime target = DateTime(now.year, now.month, now.day);
    if (code == 'yesterday') {
      target = target.subtract(const Duration(days: 1));
    } else if (code == 'bom') {
      target = DateTime(now.year, now.month, 1);
    } else if (code == 'eom') {
      target = DateTime(now.year, now.month + 1, 0);
    }
    setState(() => selectedDate = target);
    _fetchKategori(); // refresh kategori sesuai preset tanggal
    if (selectedKategori != null) {
      _fetchBahan(selectedKategori);
    }
  }

  Widget _dateFilterBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('Tanggal Input',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: _pickDate,
              icon: const Icon(Icons.date_range, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFE4E9),
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40),
                  side: const BorderSide(color: Colors.black, width: 1),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
              label: const Text('Pilih Tanggal'),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: _clearDate,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.black, width: 1),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              child: const Text('Clear'),
            ),
          ],
        ),
        const SizedBox(height: 10),
        InkWell(
          onTap: _pickDate,
          borderRadius: BorderRadius.circular(40),
          child: _DatePill(
            label: 'Tanggal',
            value: selectedDate == null ? '—' : _fmtChip.format(selectedDate!),
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: [
            _PresetChip(text: 'Hari Ini',     onTap: () => _applyPreset('today')),
            _PresetChip(text: 'Kemarin',      onTap: () => _applyPreset('yesterday')),
            _PresetChip(text: 'Awal Bulan',   onTap: () => _applyPreset('bom')),
            _PresetChip(text: 'Akhir Bulan',  onTap: () => _applyPreset('eom')),
          ],
        ),
      ],
    );
  }

  // ================== UI Helper (gaya kapsul seperti LaporanStok) ==================
  Widget _buildHeader(List<double> widths) {
    const sideInset = 20.0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: sideInset),
      child: Table(
        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
        columnWidths: { for (int i=0; i<widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(
            children: List.generate(_headers.length, (i) {
              return Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  _headers[i],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _capsuleRow({required Widget child, double top = 12}) {
    return Container(
      margin: EdgeInsets.only(top: top, left: 6, right: 6),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.08),
              blurRadius: 10, offset: const Offset(0, 4)),
        ],
        border: Border.all(color: Colors.black.withOpacity(0.05)),
      ),
      child: child,
    );
  }

  Widget _cellText(String text) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(text,
          textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
    );
  }

  Widget _cellInput(TextEditingController? c, ValueChanged<String> onChanged) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      child: TextField(
        controller: c,
        textAlign: TextAlign.center,
        keyboardType: const TextInputType.numberWithOptions(decimal: false),
        onTap: () {
          if (c != null) {
            c.selection = TextSelection(baseOffset: 0, extentOffset: c.text.length);
          }
        },
        // <- HAPUS 'const' di sini
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly,
          const _RemoveLeadingZerosFormatter(),
        ],
        onChanged: onChanged,
        decoration: const InputDecoration(
          isDense: true,
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 6),
        ),
      ),
    );
  }

  Widget _buildPlaceholder(List<double> widths) {
    return _capsuleRow(
      child: Table(
        columnWidths: { for (int i=0; i<widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(children: List.generate(widths.length, (i) => _cellText('–'))),
        ],
      ),
    );
  }

  Widget _dataRow({
    required List<double> widths,
    required Map<String, dynamic> bahan,
    required bool isFirst,
  }) {
    final id = bahan['id'].toString();
    final akhir = stokAkhir[id] ?? 0;

    // ambil harga dari data, lalu hitung total = akhir * harga
    final num harga = (bahan['harga'] is num)
        ? (bahan['harga'] as num)
        : num.tryParse((bahan['harga'] ?? '0').toString()) ?? 0;

    final num total = akhir * harga;
    final String totalStr = NumberFormat.decimalPattern('id_ID').format(total);
    final String satuanStr = (bahan['satuan'] ?? '-').toString();

    return _capsuleRow(
      top: isFirst ? 6 : 12,
      child: Table(
        columnWidths: { for (int i=0; i<widths.length; i++) i: FixedColumnWidth(widths[i]) },
        children: [
          TableRow(
            children: [
              _cellText(bahan['nama_bahan'].toString()),
              _cellInput(awalCtrl[id],  (_) => _hitungStok(id)),
              _cellInput(beliCtrl[id],  (_) => _hitungStok(id)),
              _cellInput(ambilCtrl[id], (_) => _hitungStok(id)),
              _cellText('$akhir'),
              _cellText(totalStr),     // <<< dulu '-' sekarang total harga
              _cellText(satuanStr),    // <<< tampilkan satuan
            ],
          ),
        ],
      ),
    );
  }

  // ================== BUILD ==================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Input Persedian Pokok",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
        centerTitle: false,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFC5CC), Colors.white],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            const SizedBox(height: 50),

            // Tanggal input (gaya sama)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
              child: _dateFilterBar(),
            ),

            const SizedBox(height: 10),

            // Dropdown kategori
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  contentPadding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30)),
                ),
                hint: const Text("Pilih Kategori"),
                value: selectedKategori,
                items: kategoriList
                    .map((k) => DropdownMenuItem(value: k, child: Text(k)))
                    .toList(),
                onChanged: (v) {
                  setState(() => selectedKategori = v);
                  if (v != null) _fetchBahan(v);
                },
              ),
            ),

            // ====== TABEL INPUT (UI kapsul + header sinkron) ======
            Expanded(
              child: LayoutBuilder(
                builder: (context, c) {
                  final minTotal = _baseWidths.reduce((a, b) => a + b);
                  final available = c.maxWidth - 24; // padding dalam card
                  final totalW = available >= minTotal ? available : minTotal.toDouble();
                  final scale  = totalW / minTotal;
                  final widths = _baseWidths.map((w) => w * scale).toList();
                  final tableWidth = widths.reduce((a, b) => a + b);

                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 14,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                    child: Column(
                      children: [
                        // HEADER
                        Scrollbar(
                          controller: _hHeader,
                          thumbVisibility: true,
                          child: SingleChildScrollView(
                            controller: _hHeader,
                            scrollDirection: Axis.horizontal,
                            child: SizedBox(width: tableWidth, child: _buildHeader(widths)),
                          ),
                        ),
                        const SizedBox(height: 8),

                        // BODY
                        Expanded(
                          child: Scrollbar(
                            controller: _vBody,
                            thumbVisibility: true,
                            child: SingleChildScrollView(
                              controller: _vBody,
                              child: Scrollbar(
                                controller: _hBody,
                                notificationPredicate: (n) => n.depth == 1,
                                thumbVisibility: true,
                                child: SingleChildScrollView(
                                  controller: _hBody,
                                  scrollDirection: Axis.horizontal,
                                  child: SizedBox(
                                    width: tableWidth,
                                    child: bahanList.isEmpty
                                        ? _buildPlaceholder(widths)
                                        : Column(
                                      children: List.generate(
                                        bahanList.length,
                                            (i) => _dataRow(
                                          widths: widths,
                                          bahan: bahanList[i],
                                          isFirst: i == 0,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),

            // Simpan Semua
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: _simpanData,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)),
                ),
                child: const Text(
                  "Simpan Semua",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// === Reusable kecil: pill & preset chip ===
class _DatePill extends StatelessWidget {
  final String label;
  final String value;
  const _DatePill({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E9),
        borderRadius: BorderRadius.circular(40),
        border: Border.all(color: Colors.black, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.calendar_today_rounded, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Tanggal',
                    style: const TextStyle(fontSize: 11, color: Colors.black54)),
                Text(value,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const _PresetChip({required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(40),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _RemoveLeadingZerosFormatter extends TextInputFormatter {
  const _RemoveLeadingZerosFormatter();

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    // hapus nol di depan, tapi sisakan "0" kalau kosong
    final noLeading = newValue.text.replaceFirst(RegExp(r'^0+(?=\d)'), '');
    final fixed = noLeading.isEmpty ? '0' : noLeading;
    return TextEditingValue(
      text: fixed,
      selection: TextSelection.collapsed(offset: fixed.length),
      composing: TextRange.empty,
    );
  }
}

