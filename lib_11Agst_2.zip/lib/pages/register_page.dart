import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final supabase = Supabase.instance.client;

  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  final namaCabangController = TextEditingController();
  final lokasiCabangController = TextEditingController();
  final adminKeyController = TextEditingController();

  String? selectedRole;
  String? selectedCabang;
  String? generatedCabangId;
  List<Map<String, dynamic>> cabangList = [];

  @override
  void initState() {
    super.initState();
    fetchCabang();
  }

  Future<void> fetchCabang() async {
    final response = await supabase.from('cabang').select();
    setState(() {
      cabangList = List<Map<String, dynamic>>.from(response);
    });
  }

  Future<String> generateCabangId() async {
    final data = await Supabase.instance.client
        .from('cabang')
        .select('id_cabang');

    final ids = data.map((item) => item['id_cabang'] as String).toList();

    int i = 1;
    while (true) {
      final newId = 'CB${i.toString().padLeft(3, '0')}';
      if (!ids.contains(newId)) {
        return newId;
      }
      i++;
    }
  }

  Future<void> register() async {
    final nama = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text.trim();
    final role = selectedRole;
    String? cabangId;

    if (nama.isEmpty || email.isEmpty || password.isEmpty || role == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Semua field wajib diisi')),
      );
      return;
    }

    // Validasi admin_pusat
    if (role == 'admin_pusat') {
      if (adminKeyController.text.trim() != 'RAHASIA2025') {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Kode rahasia salah')),
        );
        return;
      }
    }

    try {
      // Role admin_cabang → buat cabang baru
      if (role == 'admin_cabang') {
        cabangId = await generateCabangId();

        await supabase.from('cabang').insert({
          'id_cabang': cabangId,
          'nama_cabang': namaCabangController.text.trim(),
          'lokasi': lokasiCabangController.text.trim(),
        });
      }
      // Role staff → pilih cabang yang sudah ada
      else if (role == 'staff') {
        if (selectedCabang == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Silakan pilih cabang')),
          );
          return;
        }
        cabangId = selectedCabang;
      }
      // Role admin_pusat → tidak ada cabang
      else if (role == 'admin_pusat') {
        cabangId = '';
      }

      // Supabase Auth Sign Up (wajib kirim metadata)
      final authResponse = await supabase.auth.signUp(
        email: email,
        password: password,
        data: {
          'nama': nama,
          'role': role,
          'id_cabang': cabangId ?? '',
        },
      );

      final user = authResponse.user;
      if (user == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal mendapatkan user ID')),
        );
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Berhasil mendaftar')),
      );

      Future.delayed(const Duration(seconds: 1), () {
        Navigator.pushReplacementNamed(context, '/login');
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal mendaftar: ${e.toString()}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFFD1D1), Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Card(
              color: Colors.white.withOpacity(0.95),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 10,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        "Daftar Akun",
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 24),
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(labelText: 'Nama'),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: emailController,
                        decoration: const InputDecoration(labelText: 'Email'),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: passwordController,
                        obscureText: true,
                        decoration: const InputDecoration(labelText: 'Password'),
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        decoration: const InputDecoration(labelText: 'Role'),
                        value: selectedRole,
                        items: const [
                          DropdownMenuItem(
                            value: 'admin_pusat',
                            child: Text('Admin Pusat (khusus)'),
                          ),
                          DropdownMenuItem(
                            value: 'admin_cabang',
                            child: Text('Admin Cabang'),
                          ),
                          DropdownMenuItem(
                            value: 'staff',
                            child: Text('Staff'),
                          ),
                        ],
                        onChanged: (value) async {
                          setState(() {
                            selectedRole = value;
                            selectedCabang = null;
                            namaCabangController.clear();
                            lokasiCabangController.clear();
                          });

                          if (value == 'admin_cabang') {
                            generatedCabangId = await generateCabangId();
                          }
                        },
                      ),
                      const SizedBox(height: 16),

                      if (selectedRole == 'admin_pusat') ...[
                        TextField(
                          controller: adminKeyController,
                          decoration: const InputDecoration(
                            labelText: 'Kode Rahasia Admin Pusat',
                          ),
                          obscureText: true,
                        ),
                        const SizedBox(height: 16),
                      ],

                      if (selectedRole == 'admin_cabang') ...[
                        TextFormField(
                          initialValue: generatedCabangId ?? '',
                          decoration: const InputDecoration(labelText: 'ID Cabang'),
                          enabled: false,
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: namaCabangController,
                          decoration: const InputDecoration(labelText: 'Nama Cabang'),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: lokasiCabangController,
                          decoration: const InputDecoration(labelText: 'Lokasi'),
                        ),
                        const SizedBox(height: 12),
                      ],

                      if (selectedRole == 'staff') ...[
                        DropdownButtonFormField<String>(
                          value: selectedCabang,
                          onChanged: (val) {
                            setState(() {
                              selectedCabang = val;
                            });
                          },
                          decoration: const InputDecoration(labelText: 'Pilih Cabang'),
                          items: cabangList.map<DropdownMenuItem<String>>((cabang) {
                            return DropdownMenuItem<String>(
                              value: cabang['id_cabang'] as String,
                              child: Text('${cabang['nama_cabang']} (${cabang['id_cabang']})'),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 12),
                      ],

                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: register,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.indigo,
                          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'Daftar',
                          style: TextStyle(fontSize: 16, color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Sudah punya akun? Masuk di sini'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
